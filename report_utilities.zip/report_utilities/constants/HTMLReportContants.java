package report_utilities.constants;

import java.util.ArrayList;
import java.util.List;

public class HTMLReportContants {

	//PlaceHolders
	//TestCase
	public static final String TC_NAME ="##TCName##";
	public static final String TC_MODULE ="##ModuleName##";
	public static final String TC_BROWSER ="##Browser##";
	public static final String TC_STATUS ="##Status##";
	
	//Screenshot
	public static final String SCR_STEP_NAME ="##StepName##";
	public static final String SCR_STEP_STATUS ="##StepStatus##";
	
	//TestSteps
	public static final String TS_STEP_NAME ="##StepName##";
	public static final String TS_STEP_DESC ="##StepDesc##";
	public static final String TS_STATUS ="##Status##";
	public static final String TS_J_SCREENSHOT ="##Screenshot##";
	public static final String TS_START_TIME ="##StartTime##";
	public static final String TS_END_TIME ="##EndTime##";
	public static final String TS_DURATION ="##Duration##";
	
	//HTML FileLocation
	public static final String HTML_FILE_LOCATION ="/src/main/resources/HTML/";
	
	
	//HTML FileLocation
	public static final String TEMPLATE_HTML_INDEX ="HTMLIndex.html";
	public static final String TEMPLATE_SCREEN_SHOT ="ScreenShotTemplate.html";
	public static final String TEMPLATE_HTML_TEST_CASE ="TCTemplate.html";
	public static final String TEMPLATE_TEST_STEP_PRE ="TestStepPreTemplate.html";
	public static final String TEMPLATE_CURRENT_TEST_STEP ="TSCurrentTemplate.html";
	public static final String TEMPLATE_HTML_SUMMARY ="HTMLSummaryTemplate.html";
	public static final String TEMPLATE_HTML_SUMMARY_MODULE_BROWSER_ROW ="HTMLSummaryModuleBrowserRow.html";
	public static final String TEMPLATE_HTML_SUMMARY_TC_ROW ="HTMLSummaryTCRow.html";
	public static final String TEMPLATE_HTMLTC_LIVE_ROW ="HTMLTCLiveRow.html";
	public static final String TEMPLATE_HTMLTC_LIVE_TEMPLATE ="HTMLTCLiveTemplate.html";
	
	
	//HTML Data
	
	private static String placeHolderHTMLIndex="";
	private static String placeHolderScreenShot="";
	private static String placeHolderHTMLTestCase="";
	private static String placeHolderTestStepPre="";
	private static String placeHolderCurrentTestStep="";
	private static String placeHolderHTMLSummary="";
	private static String placeHolderHTMLSummaryModuleRow="";
	private static String placeHolderHTMLSummaryBrowserRow="";
	private static String placeHolderHTMLSummaryTCRow="";
	private static String placeHolderHTMLTCLiveRow="";
	private static String placeHolderHTMLTCLiveTemplate="";
	
	//HTMLReport File Name
	
	public static final String FILE_HTML_INDEX ="/index.html";
	public static final String FILE_SCREEN_SHOT ="/ScreenShot.html";
	public static final String FILE_SCREEN_SHOT_IMAGE ="/ScreenShot.jpeg";
	public static final String FILE_HTML_TEST_CASE ="/TCDetails.html";
	public static final String FILE_TEST_STEP ="/TSDetails.html";
	public static final String FILE_HTML_SUMMARY ="/HTML_Report_Summary.html";
	public static final String HTML_TC_LIVE_REPORT ="/HTML_TCLiveReport.html";

	//WebPage Refresh Time

	public static final String PAGE_REFRESH_TIME_IN_SECONDS_VAR ="##RefreshTime##";
	private static String pageRefreshTimeInSeconds="5";
	

	//HTML TC Live
	public static final String TC_LIVE_TC_NAME ="##TestCaseName##";
	public static final String TC_LIVE_MODULE ="##Module##";
	public static final String TC_LIVE_BROWSER ="##Browser##";
	public static final String TC_LIVE_STATUS ="##Status##";
	public static final String TC_LIVE_FILE_PATH ="##FilePath##";
	
	//HTML Summary
	
	//Module and Browser
	public static final String SUMMARY_MODULE_BROWSER_SNO ="##SNO##";
	public static final String SUMMARY_MODULE_BROWSER_MODULE ="##Module##";
	public static final String SUMMARY_MODULE_BROWSER_TOTAL_TC ="##TotalTC##";
	public static final String SUMMARY_MODULE_BROWSER_PASSED_TC ="##PassedTC##";
	public static final String SUMMARY_MODULE_BROWSER_FAILED_TC ="##FailedTC##";
	public static final String SUMMARY_MODULE_BROWSER_SKIPPED_TC ="##SkippedTC##";

	//TC Summary
	public static final String SUMMARY_TC_SNO ="##SNO##";
	public static final String SUMMARY_TC_TC_NAME ="##TestCaseName##";
	public static final String SUMMARY_TC_TC_DESC ="##TestCaseDetails##";
	public static final String SUMMARY_TC_MODULE ="##Module##";
	public static final String SUMMARY_TC_BROWSER ="##Browser##";
	public static final String SUMMARY_TC_STATUS ="##Status##";
	public static final String SUMMARY_TC_START_TIME ="##StartTime##";
	public static final String SUMMARY_TC_END_TIME ="##EndTime##";
	public static final String SUMMARY_TC_DURATION ="##Duration##";

	//PlaceHolders for DataRow
	public static final String SUMMARY_DATA_ROW_MODULE ="###ModuleData###";
	public static final String SUMMARY_DATA_ROW_BROWSER ="###BrowserData###";
	public static final String SUMMARY_DATA_ROW_TC ="###TestCaseData###";
	
	
	
	//New Files
	//JSON Data File Path
	
	private static  String htmlJSONDataFilePath ="";
	private static  String htmlResultsDir ="";
	
	
	
	//Static
	//TestSummary
	
	public static final String SUMMARY_DASHBOARD ="Dashboard.html";
	public static final String SUMMARY_JS ="script.js";
	public static final String SUMMARY_CSS ="style.css";
	public static final String SUMMARY_JSON ="data.json";
	
	
	
	//TestSummary
	
	public static final String TEST_CASE_HTML ="TestCase.html";
	public static final String TCSCRIPT_JS ="TCscript.js";
	public static final String TEST_CASE_CSS ="TCstyle.css";
	public static final String TEST_CASE_JSON ="TCData.json";

	public static final String TEST_CASE_JS_OUTPUT ="script.js";
	public static final String TEST_CASE_CSS_OUTPUT ="style.css";

	
	

	
	
	//Data for Summary and TestCase
	
	
	

	
	
	//Data from the files
	
	private static  String summaryDataHTML="";
	private static  List<String> summaryDataCSS=new ArrayList<>();
	private static  List<String> htmlSummaryDataJS=new ArrayList<>();
	private static  String summaryJSONFilePath="";
	
	private static  String testCaseDataHTML="";

	private static  List<String> testCaseDataCSS=new ArrayList<>();
	private static  List<String> testCaseDataJS =new ArrayList<>();
	private static  String testCaseJSONFilePath ="";
	//HTML Reports Directory
	private static String htmlreportsdir ="";
	private static String tsScreenshot ="";
	public static final String HTML_REPORTS_DIR_NAME ="/HTMLReports/";
	public static String getHtmlreportsdir() {
		return htmlreportsdir;
	}
	public static void setHtmlreportsdir(String htmlreportsdir) {
		HTMLReportContants.htmlreportsdir = htmlreportsdir;
	}
	public static List<String> getTestCaseDataJS() {
		return testCaseDataJS;
	}
	public static void setTestCaseDataJS(List<String> testCaseDataJS) {
		HTMLReportContants.testCaseDataJS = testCaseDataJS;
	}
	public static String getTestCaseJSONFilePath() {
		return testCaseJSONFilePath;
	}
	public static void setTestCaseJSONFilePath(String testCaseJSONFilePath) {
		HTMLReportContants.testCaseJSONFilePath = testCaseJSONFilePath;
	}
	public static String getTsScreenshot() {
		return tsScreenshot;
	}
	public static void setTsScreenshot(String tsScreenshot) {
		HTMLReportContants.tsScreenshot = tsScreenshot;
	}
	public static List<String> getTestCaseDataCSS() {
		return testCaseDataCSS;
	}
	public static void setTestCaseDataCSS(List<String> testCaseDataCSS) {
		HTMLReportContants.testCaseDataCSS = testCaseDataCSS;
	}
	public static String getTestCaseDataHTML() {
		return testCaseDataHTML;
	}
	public static void setTestCaseDataHTML(String testCaseDataHTML) {
		HTMLReportContants.testCaseDataHTML = testCaseDataHTML;
	}
	public static String getSummaryJSONFilePath() {
		return summaryJSONFilePath;
	}
	public static void setSummaryJSONFilePath(String summaryJSONFilePath) {
		HTMLReportContants.summaryJSONFilePath = summaryJSONFilePath;
	}
	public static List<String> getHtmlSummaryDataJS() {
		return htmlSummaryDataJS;
	}
	public static void setHtmlSummaryDataJS(List<String> htmlSummaryDataJS) {
		HTMLReportContants.htmlSummaryDataJS = htmlSummaryDataJS;
	}
	public static String getSummaryDataHTML() {
		return summaryDataHTML;
	}
	public static void setSummaryDataHTML(String summaryDataHTML) {
		HTMLReportContants.summaryDataHTML = summaryDataHTML;
	}
	public static String getHtmlJSONDataFilePath() {
		return htmlJSONDataFilePath;
	}
	public static void setHtmlJSONDataFilePath(String htmlJSONDataFilePath) {
		HTMLReportContants.htmlJSONDataFilePath = htmlJSONDataFilePath;
	}
	public static String getHtmlResultsDir() {
		return htmlResultsDir;
	}
	public static void setHtmlResultsDir(String htmlResultsDir) {
		HTMLReportContants.htmlResultsDir = htmlResultsDir;
	}
	public static String getPageRefreshTimeInSeconds() {
		return pageRefreshTimeInSeconds;
	}
	public static void setPageRefreshTimeInSeconds(String pageRefreshTimeInSeconds) {
		HTMLReportContants.pageRefreshTimeInSeconds = pageRefreshTimeInSeconds;
	}
	public static String getPlaceHolderHTMLTCLiveTemplate() {
		return placeHolderHTMLTCLiveTemplate;
	}
	public static void setPlaceHolderHTMLTCLiveTemplate(String placeHolderHTMLTCLiveTemplate) {
		HTMLReportContants.placeHolderHTMLTCLiveTemplate = placeHolderHTMLTCLiveTemplate;
	}
	public static String getPlaceHolderHTMLSummaryTCRow() {
		return placeHolderHTMLSummaryTCRow;
	}
	public static void setPlaceHolderHTMLSummaryTCRow(String placeHolderHTMLSummaryTCRow) {
		HTMLReportContants.placeHolderHTMLSummaryTCRow = placeHolderHTMLSummaryTCRow;
	}
	public static String getPlaceHolderHTMLSummaryBrowserRow() {
		return placeHolderHTMLSummaryBrowserRow;
	}
	public static void setPlaceHolderHTMLSummaryBrowserRow(String placeHolderHTMLSummaryBrowserRow) {
		HTMLReportContants.placeHolderHTMLSummaryBrowserRow = placeHolderHTMLSummaryBrowserRow;
	}
	public static String getPlaceHolderHTMLTCLiveRow() {
		return placeHolderHTMLTCLiveRow;
	}
	public static void setPlaceHolderHTMLTCLiveRow(String placeHolderHTMLTCLiveRow) {
		HTMLReportContants.placeHolderHTMLTCLiveRow = placeHolderHTMLTCLiveRow;
	}
	public static String getPlaceHolderHTMLSummaryModuleRow() {
		return placeHolderHTMLSummaryModuleRow;
	}
	public static void setPlaceHolderHTMLSummaryModuleRow(String placeHolderHTMLSummaryModuleRow) {
		HTMLReportContants.placeHolderHTMLSummaryModuleRow = placeHolderHTMLSummaryModuleRow;
	}
	public static String getPlaceHolderCurrentTestStep() {
		return placeHolderCurrentTestStep;
	}
	public static void setPlaceHolderCurrentTestStep(String placeHolderCurrentTestStep) {
		HTMLReportContants.placeHolderCurrentTestStep = placeHolderCurrentTestStep;
	}
	public static String getPlaceHolderHTMLSummary() {
		return placeHolderHTMLSummary;
	}
	public static void setPlaceHolderHTMLSummary(String placeHolderHTMLSummary) {
		HTMLReportContants.placeHolderHTMLSummary = placeHolderHTMLSummary;
	}
	public static String getPlaceHolderHTMLTestCase() {
		return placeHolderHTMLTestCase;
	}
	public static void setPlaceHolderHTMLTestCase(String placeHolderHTMLTestCase) {
		HTMLReportContants.placeHolderHTMLTestCase = placeHolderHTMLTestCase;
	}
	public static String getPlaceHolderHTMLIndex() {
		return placeHolderHTMLIndex;
	}
	public static void setPlaceHolderHTMLIndex(String placeHolderHTMLIndex) {
		HTMLReportContants.placeHolderHTMLIndex = placeHolderHTMLIndex;
	}
	public static List<String> getSummaryDataCSS() {
		return summaryDataCSS;
	}
	public static void setSummaryDataCSS(List<String> summaryDataCSS) {
		HTMLReportContants.summaryDataCSS = summaryDataCSS;
	}
	public static String getPlaceHolderTestStepPre() {
		return placeHolderTestStepPre;
	}
	public static void setPlaceHolderTestStepPre(String placeHolderTestStepPre) {
		HTMLReportContants.placeHolderTestStepPre = placeHolderTestStepPre;
	}
	public static String getPlaceHolderScreenShot() {
		return placeHolderScreenShot;
	}
	public static void setPlaceHolderScreenShot(String placeHolderScreenShot) {
		HTMLReportContants.placeHolderScreenShot = placeHolderScreenShot;
	}

	HTMLReportContants()
	{
		
	}

}