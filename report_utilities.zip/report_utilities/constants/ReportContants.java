package report_utilities.constants;

import java.util.ArrayList;
import java.util.List;

import report_utilities.html_model.HTMLTCLiveModel;
import report_utilities.test_result_model.BrowserResult;
import report_utilities.test_result_model.ModuleResult;
import report_utilities.test_result_model.TestCaseResult;


public class ReportContants
{
	private static boolean isScreenShotforAllPass = false; 
	private static boolean isFullPageScreenShot = false;
	private static String resultsFolder = "";
	private static List<TestCaseResult> testcaseResults= new ArrayList<>();
	private static List<ModuleResult> moduleResults= new ArrayList<>();
	private static List<BrowserResult> browserResults= new ArrayList<>();
	private static List<HTMLTCLiveModel> htmlTCLiveModels= new ArrayList<>();
	private static boolean replaceExistingSnapshotForAllPass=false;
	private static String statusInProgress="InProgress";
	private static String statusCompleted="Completed";
	private static String statusNotStarted="Not Started";
	private static String statusDone="Done";
	private static String statusPass="Pass";
	private static String statusFail="Failed";

	ReportContants()
	{
		
	}
	
	
	ReportContants(String resultsFolder, boolean isScreenShotforPass, boolean isfullPageScreenShot)
	{
		setFullPageScreenShot(isfullPageScreenShot);
		setResultsFolder(resultsFolder);
		setScreenShotforAllPass(isScreenShotforPass);
	}


	public static String getResultsFolder() {
		return resultsFolder;
	}


	public static void setResultsFolder(String resultsFolder) {
		ReportContants.resultsFolder = resultsFolder;
	}

	public static String getStatusCompleted() {
		return statusCompleted;
	}


	public static void setStatusCompleted(String statusCompleted) {
		ReportContants.statusCompleted = statusCompleted;
	}


	public static String getStatusDone() {
		return statusDone;
	}


	public static void setStatusDone(String statusDone) {
		ReportContants.statusDone = statusDone;
	}


	public static String getStatusInProgress() {
		return statusInProgress;
	}


	public static void setStatusInProgress(String statusInProgress) {
		ReportContants.statusInProgress = statusInProgress;
	}


	public static String getStatusPass() {
		return statusPass;
	}


	public static void setStatusPass(String statusPass) {
		ReportContants.statusPass = statusPass;
	}


	public static String getStatusFail() {
		return statusFail;
	}


	public static void setStatusFail(String statusFail) {
		ReportContants.statusFail = statusFail;
	}


	public static String getStatusNotStarted() {
		return statusNotStarted;
	}


	public static void setStatusNotStarted(String statusNotStarted) {
		ReportContants.statusNotStarted = statusNotStarted;
	}


	public static List<BrowserResult> getBrowserResults() {
		return browserResults;
	}


	public static void setBrowserResults(List<BrowserResult> browserResults) {
		ReportContants.browserResults = browserResults;
	}


	public static List<HTMLTCLiveModel> getHtmlTCLiveModels() {
		return htmlTCLiveModels;
	}


	public static void setHtmlTCLiveModels(List<HTMLTCLiveModel> htmlTCLiveModels) {
		ReportContants.htmlTCLiveModels = htmlTCLiveModels;
	}


	public static List<ModuleResult> getModuleResults() {
		return moduleResults;
	}


	public static void setModuleResults(List<ModuleResult> moduleResults) {
		ReportContants.moduleResults = moduleResults;
	}


	public static List<TestCaseResult> getTestcaseResults() {
		return testcaseResults;
	}


	public static void setTestcaseResults(List<TestCaseResult> testcaseResults) {
		ReportContants.testcaseResults = testcaseResults;
	}


	public static boolean isFullPageScreenShot() {
		return isFullPageScreenShot;
	}


	public static void setFullPageScreenShot(boolean isFullPageScreenShot) {
		ReportContants.isFullPageScreenShot = isFullPageScreenShot;
	}


	public static boolean isScreenShotforAllPass() {
		return isScreenShotforAllPass;
	}


	public static void setScreenShotforAllPass(boolean isScreenShotforAllPass) {
		ReportContants.isScreenShotforAllPass = isScreenShotforAllPass;
	}


	public static boolean isReplaceExistingSnapshotForAllPass() {
		return replaceExistingSnapshotForAllPass;
	}


	public static void setReplaceExistingSnapshotForAllPass(boolean replaceExistingSnapshotForAllPass) {
		ReportContants.replaceExistingSnapshotForAllPass = replaceExistingSnapshotForAllPass;
	} 
 


}