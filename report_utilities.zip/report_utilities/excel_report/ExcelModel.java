package report_utilities.excel_report;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExcelModel
{
	private String sheetName = "";
	private List<String> headerData = new ArrayList<>();
	private Map<Integer, List<String>> tableData = new HashMap<>();
	public String getSheetName() {
		return sheetName;
	}
	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}
	public List<String> getHeaderData() {
		return headerData;
	}
	public void setHeaderData(List<String> headerData) {
		this.headerData = headerData;
	}
	public Map<Integer, List<String>> getTableData() {
		return tableData;
	}
	public void setTableData(Map<Integer, List<String>> tableData) {
		this.tableData = tableData;
	}
}