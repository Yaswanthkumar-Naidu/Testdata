package report_utilities.excel_report;


import org.apache.poi.common.usermodel.HyperlinkType;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import report_utilities.common.ReportCommon;
import report_utilities.extent_model.TestStepDetails;
import report_utilities.extent_model.TestStepDetails.TestStepType;
import report_utilities.test_result_model.BrowserResult;
import report_utilities.test_result_model.ModuleResult;
import report_utilities.test_result_model.TestCaseResult;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class ExcelReportCommon {
	
	String fontName = "Verdana";

	private static final Logger logger =LoggerFactory.getLogger(ExcelReportCommon.class.getName());
	public Workbook createWorkbook()
	{
        return new XSSFWorkbook();  // new HSSFWorkbook() for generating `.xls` file
	}
	
	public CreationHelper createExcelHelper(Workbook workbook)
	{
		return workbook.getCreationHelper();
		
	}
	
	/**
	 * @param workbook
	 * @param sheetName
	 */
	public Sheet createSheet(Workbook workbook,String sheetName) {
		  return workbook.createSheet(sheetName);
	}
	
	public void createHeader(Workbook workbook, Sheet sheet,List<String> columns,List<Integer> columnSize ,int startRow) throws FileNotFoundException
	{
	        // Create a Row
	        Row headerRow = sheet.createRow(startRow);
	        CellStyle headerStyle= getHeaderCellStyle(workbook);
	        // Creating cells
	        for(int i = 0; i < columns.size(); i++) {
	            Cell cell = headerRow.createCell(i);
	            cell.setCellValue(columns.get(i));
	            cell.setCellStyle(headerStyle);
	            sheet.setColumnWidth(i, columnSize.get(i));
	        }

	}
	
	public void addTestStepDetails(Workbook workbook, Sheet sheet, CreationHelper createHelper, List<TestStepDetails> rowdata) {
	    int rowNum = 1;
	    int sNumber = 1;
	    for (TestStepDetails teststepmodel : rowdata) {
	        Row row = sheet.createRow(rowNum++);
	        if (isModuleOrScreenStep(teststepmodel)) {
	            addModuleOrScreenStep(workbook, row, teststepmodel);
	        } else {
	            addRegularStep(workbook, createHelper, row, teststepmodel, sNumber++);
	        }
	    }
	}

	private boolean isModuleOrScreenStep(TestStepDetails teststepmodel) {
	    return teststepmodel.testStepType == TestStepType.MODULE ||
	           teststepmodel.testStepType == TestStepType.SCREEN ||
	           teststepmodel.testStepType == TestStepType.MODULE_SCREEN;
	}

	private void addModuleOrScreenStep(Workbook workbook, Row row, TestStepDetails teststepmodel) {
	    String stepDetails = getStepDetails(teststepmodel);

	    createCell(row, 0, getLeftBorderStyle(workbook));
	    createCell(row, 1, getNoSideBorderStyle(workbook));
	    createCell(row, 2, stepDetails, getNoSideBorderStyle(workbook));
	    createCell(row, 3, getNoSideBorderStyle(workbook));
	    createCell(row, 4, getNoSideBorderStyle(workbook));
	    createCell(row, 5, getNoSideBorderStyle(workbook));
	    createCell(row, 6, getNoSideBorderStyle(workbook));
	    createCell(row, 7, getNoSideBorderStyle(workbook));
	    createCell(row, 8, getNoSideBorderStyle(workbook));
	    createCell(row, 9, getRightBorderStyle(workbook));
	}

	private String getStepDetails(TestStepDetails teststepmodel) {
	    switch (teststepmodel.testStepType) {
	        case MODULE:
	            return "Module : " + teststepmodel.moduleName;
	        case SCREEN:
	            return "Screen : " + teststepmodel.screenName;
	        case MODULE_SCREEN:
	            return "Module : " + teststepmodel.moduleName + " ===> Screen : " + teststepmodel.screenName;
	        default:
	            return "";
	    }
	}

	private void addRegularStep(Workbook workbook, CreationHelper createHelper, Row row, TestStepDetails teststepmodel, int sNumber) {
	    CellStyle rowCellStyle = getGenericCellStyle(workbook);

	    createCell(row, 0, sNumber, getGenericCellStyleMiddle(workbook));
	    createCell(row, 1, teststepmodel.stepName, rowCellStyle);
	    createCell(row, 2, teststepmodel.stepDescription, rowCellStyle);
	    createStatusCell(workbook, row, teststepmodel);
	    createTimeCells(workbook, createHelper, row, teststepmodel);
	    createScreenshotCell(workbook, createHelper, row, teststepmodel, rowCellStyle);
	    createErrorMessageCell(workbook,row, teststepmodel, rowCellStyle);
	    createErrorDetailsCell(workbook,row, teststepmodel, rowCellStyle);
	}

	private void createCell(Row row, int column, String value, CellStyle style) {
	    Cell cell = row.createCell(column);
	    cell.setCellValue(value);
	    cell.setCellStyle(style);
	}

	private void createCell(Row row, int column, CellStyle style) {
	    Cell cell = row.createCell(column);
	    cell.setCellStyle(style);
	}

	private void createCell(Row row, int column, int value, CellStyle style) {
	    Cell cell = row.createCell(column);
	    cell.setCellValue(value);
	    cell.setCellStyle(style);
	}

	private void createStatusCell(Workbook workbook, Row row, TestStepDetails teststepmodel) {
	    CellStyle style;
	    String status = teststepmodel.extentStatus.name();
	    if (status.toUpperCase().contains("PASS")) {
	        style = getPassCellStyle(workbook);
	    } else if (status.toUpperCase().contains("FAIL")) {
	        style = getFailCellStyle(workbook);
	    } else if (status.toUpperCase().contains("INFO")) {
	        status = "DONE";
	        style = getGenericCellStyleMiddle(workbook);
	    } else {
	        style = getGenericCellStyleMiddle(workbook);
	    }
	    createCell(row, 3, status, style);
	}

	private void createTimeCells(Workbook workbook, CreationHelper createHelper, Row row, TestStepDetails teststepmodel) {
	    ReportCommon rcommon = new ReportCommon();
	    createCell(row, 4, rcommon.convertLocalDateTimetoSQLDateTime(teststepmodel.startTime), getDateTimeCellStyle(workbook, createHelper));
	    createCell(row, 5, rcommon.convertLocalDateTimetoSQLDateTime(teststepmodel.endTime), getDateTimeCellStyle(workbook, createHelper));
	    createCell(row, 6, rcommon.getDuration(teststepmodel.startTime, teststepmodel.endTime), getGenericCellStyleMiddle(workbook));
	}

	private void createScreenshotCell(Workbook workbook, CreationHelper createHelper, Row row, TestStepDetails teststepmodel, CellStyle rowCellStyle) {
	    Cell screenshot = row.createCell(7);
	    if (!teststepmodel.screenShotData.isEmpty()) {
	        try {
	            screenshot.setCellValue("Screenshot");
	            screenshot.setHyperlink(getHyperLinkScreenshot( createHelper, teststepmodel.screenShotData));
	            screenshot.setCellStyle(getHyperLinkCellStyle(workbook));
	        } catch (Exception e) {
	            screenshot.setCellValue("Missing Screenshot");
	            screenshot.setCellStyle(rowCellStyle);
	        }
	    } else {
	        screenshot.setCellValue("N\\A");
	        screenshot.setCellStyle(getGenericCellStyleMiddle(workbook));
	    }
	}

	private void createErrorMessageCell(Workbook workbook,Row row, TestStepDetails teststepmodel, CellStyle rowCellStyle) {
	    Cell errorMessage = row.createCell(8);
	    if (!teststepmodel.errorMessage.isEmpty()) {
	        errorMessage.setCellValue(teststepmodel.errorMessage);
	        errorMessage.setCellStyle(rowCellStyle);
	    } else {
	        errorMessage.setCellValue("N\\A");
	        errorMessage.setCellStyle(getGenericCellStyleMiddle(workbook));
	    }
	}

	private void createErrorDetailsCell(Workbook workbook,Row row, TestStepDetails teststepmodel, CellStyle rowCellStyle) {
	    Cell errorDetails = row.createCell(9);
	    if (!teststepmodel.errorDetails.isEmpty()) {
	        errorDetails.setCellValue(teststepmodel.errorDetails);
	        errorDetails.setCellStyle(rowCellStyle);
	    } else {
	        errorDetails.setCellValue("N\\A");
	        errorDetails.setCellStyle(getGenericCellStyleMiddle(workbook));
	    }
	}
	
	public void addTestCaseDetails(Workbook workbook, Sheet sheet,CreationHelper createHelper, List<TestCaseResult> testCaseResults)
	{
        int rowNum = 1;
        for(TestCaseResult testCaseResult : testCaseResults) {
            Row row = sheet.createRow(rowNum++);

            row.createCell(0)
            .setCellValue(rowNum-1.0);

            Cell sNO = row.createCell(0);
            sNO.setCellValue(rowNum-1.0);
            sNO.setCellStyle(getGenericCellStyleMiddle(workbook));
            
     	   Cell tcName = row.createCell(1);
     	  tcName.setCellValue(testCaseResult.getTestcaseName());
		try
		{
			tcName.setCellStyle(getHyperLinkCellStyle(workbook));
			Hyperlink link = createHelper.createHyperlink(HyperlinkType.DOCUMENT);
			link.setAddress("'" + testCaseResult.getTestcaseName()+"'!A1");
			tcName.setHyperlink(link);
			

		}
		catch(Exception e)
		{
			logger.info(e.getMessage());
			logger.info(Arrays.toString(e.getStackTrace()));

		}
		
		  Cell tcDesc = row.createCell(2);
		  tcDesc.setCellValue(testCaseResult.getTestcaseDescription());
		  tcDesc.setCellStyle(getGenericCellStyle(workbook));
     	 

		  Cell module = row.createCell(3);
		  module.setCellValue(testCaseResult.getModule());
		  module.setCellStyle(getGenericCellStyleMiddle(workbook));
		  
		  
		  Cell testcaseCategory = row.createCell(4);
		  testcaseCategory.setCellValue(testCaseResult.getTestcaseCategory());
		  testcaseCategory.setCellStyle(getGenericCellStyleMiddle(workbook));
		  
		  Cell caseNumber = row.createCell(5);
		  caseNumber.setCellValue(testCaseResult.getCaseNumber());
		  caseNumber.setCellStyle(getGenericCellStyleMiddle(workbook));
		  
		  Cell applicationNumber = row.createCell(6);
		  applicationNumber.setCellValue(testCaseResult.getApplicationNumber());
		  applicationNumber.setCellStyle(getGenericCellStyleMiddle(workbook));

		  Cell browser = row.createCell(7);
		  browser.setCellValue(testCaseResult.getBrowser());
		  browser.setCellStyle(getGenericCellStyleMiddle(workbook));

		  
	
            if(testCaseResult.getTestcaseStatus().equalsIgnoreCase("PASS"))
            {
            	   Cell passStatus = row.createCell(8);
            	   passStatus.setCellValue(testCaseResult.getTestcaseStatus());
            	   passStatus.setCellStyle(getPassCellStyle(workbook));
            	
            }

            else if(testCaseResult.getTestcaseStatus().equalsIgnoreCase("FAIL"))
            {
            	   Cell failStatus = row.createCell(8);
            	   failStatus.setCellValue(testCaseResult.getTestcaseStatus());
            	   failStatus.setCellStyle(getFailCellStyle(workbook));
            	
            }
            else
            {

      		  Cell testcaseStatus = row.createCell(8);
      		testcaseStatus.setCellValue(testCaseResult.getTestcaseStatus());
      		testcaseStatus.setCellStyle(getGenericCellStyleMiddle(workbook));

                

            }
            ReportCommon rcommon=new ReportCommon();
            
            Cell startTime = row.createCell(9);
            startTime.setCellValue(rcommon.convertLocalDateTimetoSQLDateTime(testCaseResult.getStartTime()));
            startTime.setCellStyle(getDateTimeCellStyle(workbook, createHelper));

            Cell endTime = row.createCell(10);
            endTime.setCellValue(rcommon.convertLocalDateTimetoSQLDateTime(testCaseResult.getEndTime()));
            endTime.setCellStyle(getDateTimeCellStyle(workbook, createHelper));
 

    		  Cell duration = row.createCell(11);
    		  duration.setCellValue(testCaseResult.getDuration());
    		  duration.setCellStyle(getGenericCellStyleMiddle(workbook));
    		  
    		
    		  
        
        }

	}

	public void addTestModuleDetails(Workbook workbook, Sheet sheet, List<ModuleResult> moduleResults)
	{
        int rowNum = 1;
        for(ModuleResult moduleResult : moduleResults) {
            Row row = sheet.createRow(rowNum++);
            
            ExcelRunSettings.setDashboardRowCounter(rowNum);

            Cell sNo = row.createCell(0);
            sNo.setCellValue(rowNum-1.0);
            sNo.setCellStyle(getGenericCellStyleMiddle(workbook));
            

            Cell module = row.createCell(1);
            module.setCellValue(moduleResult.getModule());
            module.setCellStyle(getGenericCellStyleMiddle(workbook));
            

            Cell tcTotalCount = row.createCell(2);
            tcTotalCount.setCellValue(moduleResult.getTcTotalCount());
            tcTotalCount.setCellStyle(getGenericCellStyleMiddle(workbook));

            

            Cell tcPassCount = row.createCell(3);
            tcPassCount.setCellValue(moduleResult.getTcPassCount());
            tcPassCount.setCellStyle(getGenericCellStyleMiddle(workbook));

            

            Cell tcFailCount = row.createCell(4);
            tcFailCount.setCellValue(moduleResult.getTcFailCount());
            tcFailCount.setCellStyle(getGenericCellStyleMiddle(workbook));
            
            

            Cell tcSkippedCount = row.createCell(5);
            tcSkippedCount.setCellValue(moduleResult.getTcSkippedCount());
            tcSkippedCount.setCellStyle(getGenericCellStyleMiddle(workbook));

        }
	}

	public void addTestBrowserDetails(Workbook workbook, Sheet sheet,List<BrowserResult> browserResults)
	{
		ExcelRunSettings.setDashboardRowCounter(ExcelRunSettings.getDashboardRowCounter()+1);
		int rowNum = ExcelRunSettings.getDashboardRowCounter();
		int browserRowNo=1;
        for(BrowserResult browserResult : browserResults) {
            Row row = sheet.createRow(rowNum++);
            
       
            Cell sNo = row.createCell(0);
            sNo.setCellValue(browserRowNo++);
            sNo.setCellStyle(getGenericCellStyleMiddle(workbook));
            

            Cell module = row.createCell(1);
            module.setCellValue(browserResult.getBrowser());
            module.setCellStyle(getGenericCellStyleMiddle(workbook));
            

            Cell tcTotalCount = row.createCell(2);
            tcTotalCount.setCellValue(browserResult.getTcTotalCount());
            tcTotalCount.setCellStyle(getGenericCellStyleMiddle(workbook));

            

            Cell tcPassCount = row.createCell(3);
            tcPassCount.setCellValue(browserResult.getTcPassCount());
            tcPassCount.setCellStyle(getGenericCellStyleMiddle(workbook));

            

            Cell tcFailCount = row.createCell(4);
            tcFailCount.setCellValue(browserResult.getTcFailCount());
            tcFailCount.setCellStyle(getGenericCellStyleMiddle(workbook));
            
            

            Cell tcSkippedCount = row.createCell(5);
            tcSkippedCount.setCellValue(browserResult.getTcSkippedCount());
            tcSkippedCount.setCellStyle(getGenericCellStyleMiddle(workbook));

        
        
        }

	}

	public CellStyle getDateCellStyle(Workbook workbook,CreationHelper createHelper)
	{
        CellStyle dateCellStyle = workbook.createCellStyle();
        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("dd-MM-yyyy"));
        dateCellStyle.setBorderTop(BorderStyle.THICK);
        dateCellStyle.setBorderLeft(BorderStyle.THICK);
        dateCellStyle.setBorderRight(BorderStyle.THICK);
        dateCellStyle.setBorderBottom(BorderStyle.THICK);
        dateCellStyle.setAlignment(HorizontalAlignment.CENTER);
        return dateCellStyle;
	}

	
	
	public CellStyle getDateTimeCellStyle(Workbook workbook,CreationHelper createHelper)
	{
        CellStyle dateCellStyle = workbook.createCellStyle();
        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("dd-MM-yyyy HH:MM:SS.SSS"));
        dateCellStyle.setBorderTop(BorderStyle.THICK);
        dateCellStyle.setBorderLeft(BorderStyle.THICK);
        dateCellStyle.setBorderRight(BorderStyle.THICK);
        dateCellStyle.setBorderBottom(BorderStyle.THICK);
        dateCellStyle.setAlignment(HorizontalAlignment.CENTER);
        return dateCellStyle;
	}

	public CellStyle getPassCellStyle(Workbook workbook)
	{
	     Font passFont = workbook.createFont();
	     passFont.setBold(false);
	     passFont.setFontHeightInPoints((short) 9);
	     passFont.setFontName(fontName);
	     passFont.setColor(IndexedColors.DARK_GREEN.getIndex());

	        // Create a CellStyle with the font
	        CellStyle passCellStyle = workbook.createCellStyle();
	        passCellStyle.setFont(passFont);
	        passCellStyle.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
	        
	        passCellStyle.setFillBackgroundColor(IndexedColors.LIGHT_GREEN.getIndex());
	        passCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	        passCellStyle.setAlignment(HorizontalAlignment.CENTER);
	        passCellStyle.setBorderTop(BorderStyle.THICK);
	        passCellStyle.setBorderLeft(BorderStyle.THICK);
	        passCellStyle.setBorderRight(BorderStyle.THICK);
	        passCellStyle.setBorderBottom(BorderStyle.THICK);
	        passCellStyle.setAlignment(HorizontalAlignment.CENTER);
	return passCellStyle;
	}

	public CellStyle getFailCellStyle(Workbook workbook)
	{
	     Font failFont = workbook.createFont();
	     failFont.setBold(false);
	     failFont.setFontHeightInPoints((short) 9);
	     failFont.setFontName(fontName);
	     failFont.setColor(IndexedColors.DARK_RED.getIndex());

	        // Create a CellStyle with the font
	        CellStyle failCellStyle = workbook.createCellStyle();
	        failCellStyle.setFont(failFont);
	        failCellStyle.setFillBackgroundColor(IndexedColors.RED.getIndex());
	        failCellStyle.setFillForegroundColor(IndexedColors.RED.getIndex());
	        failCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

	        failCellStyle.setBorderTop(BorderStyle.THICK);
	        failCellStyle.setBorderLeft(BorderStyle.THICK);
	        failCellStyle.setBorderRight(BorderStyle.THICK);
	        failCellStyle.setBorderBottom(BorderStyle.THICK);
	        failCellStyle.setAlignment(HorizontalAlignment.CENTER);
	        return failCellStyle;
	}

	
	public CellStyle getHyperLinkCellStyle(Workbook workbook)
	{
	     Font hLinkFont = workbook.createFont();
	     hLinkFont.setBold(false);
	     hLinkFont.setFontHeightInPoints((short) 9);
	     hLinkFont.setFontName(fontName);
	     hLinkFont.setColor(IndexedColors.BLUE.getIndex());
	     
	     hLinkFont.setUnderline(Font.U_SINGLE);

	        // Create a CellStyle with the font
	        CellStyle hlinkCellStyle = workbook.createCellStyle();
	        hlinkCellStyle.setFont(hLinkFont);
	        hlinkCellStyle.setBorderTop(BorderStyle.THICK);
	        hlinkCellStyle.setBorderLeft(BorderStyle.THICK);
	        hlinkCellStyle.setBorderRight(BorderStyle.THICK);
	        hlinkCellStyle.setBorderBottom(BorderStyle.THICK);
	        hlinkCellStyle.setAlignment(HorizontalAlignment.CENTER);
	        return hlinkCellStyle;
	}

	
	public CellStyle getGenericCellStyle(Workbook workbook)
	{
		
        Font rowFont = workbook.createFont();
        rowFont.setBold(false);
        rowFont.setFontHeightInPoints((short) 9);
        rowFont.setFontName(fontName);
        rowFont.setColor(IndexedColors.BLACK.getIndex());

        CellStyle rowCellStyle = workbook.createCellStyle();
        rowCellStyle.setFont(rowFont);
        rowCellStyle.setBorderTop(BorderStyle.THICK);
        rowCellStyle.setBorderLeft(BorderStyle.THICK);
        rowCellStyle.setBorderRight(BorderStyle.THICK);
        rowCellStyle.setBorderBottom(BorderStyle.THICK);
        rowCellStyle.setAlignment(HorizontalAlignment.LEFT);
        rowCellStyle.setWrapText(true);
		return rowCellStyle;
    

	}

	public CellStyle getGenericCellStyleMiddle(Workbook workbook)
	{
		
        Font rowFont = workbook.createFont();
        rowFont.setBold(false);
        rowFont.setFontHeightInPoints((short) 9);
        rowFont.setFontName(fontName);
        rowFont.setColor(IndexedColors.BLACK.getIndex());

        CellStyle rowCellStyle = workbook.createCellStyle();
        rowCellStyle.setFont(rowFont);
        rowCellStyle.setBorderTop(BorderStyle.THICK);
        rowCellStyle.setBorderLeft(BorderStyle.THICK);
        rowCellStyle.setBorderRight(BorderStyle.THICK);
        rowCellStyle.setBorderBottom(BorderStyle.THICK);
        rowCellStyle.setWrapText(true);
        rowCellStyle.setAlignment(HorizontalAlignment.CENTER);
		return rowCellStyle;
    

	}

	
	public CellStyle getLeftBorderStyle(Workbook workbook)
	{
		
        Font rowFont = workbook.createFont();
        rowFont.setBold(false);
        rowFont.setFontHeightInPoints((short) 9);
        rowFont.setFontName(fontName);
        rowFont.setColor(IndexedColors.BLACK.getIndex());

        CellStyle rowCellStyle = workbook.createCellStyle();
        rowCellStyle.setFillBackgroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
        rowCellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        rowCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        rowCellStyle.setFont(rowFont);
        rowCellStyle.setBorderTop(BorderStyle.THICK);
        rowCellStyle.setBorderLeft(BorderStyle.THICK);
        rowCellStyle.setBorderRight(BorderStyle.NONE);
        rowCellStyle.setBorderBottom(BorderStyle.THICK);
        rowCellStyle.setWrapText(false);
        rowCellStyle.setAlignment(HorizontalAlignment.CENTER);
		return rowCellStyle;
    

	}

	
	public CellStyle getRightBorderStyle(Workbook workbook)
	{
		
        Font rowFont = workbook.createFont();
        rowFont.setBold(false);
        rowFont.setFontHeightInPoints((short) 9);
        rowFont.setFontName(fontName);
        rowFont.setColor(IndexedColors.BLACK.getIndex());

        CellStyle rowCellStyle = workbook.createCellStyle();
        rowCellStyle.setFillBackgroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
        rowCellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        rowCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        rowCellStyle.setFont(rowFont);
        rowCellStyle.setBorderTop(BorderStyle.THICK);
        rowCellStyle.setBorderLeft(BorderStyle.NONE);
        rowCellStyle.setBorderRight(BorderStyle.THICK);
        rowCellStyle.setBorderBottom(BorderStyle.THICK);
        rowCellStyle.setWrapText(false);
        rowCellStyle.setAlignment(HorizontalAlignment.CENTER);
		return rowCellStyle;
  

	}

	
	
	public CellStyle getNoSideBorderStyle(Workbook workbook)
	{
		
        Font rowFont = workbook.createFont();
        rowFont.setBold(true);
        rowFont.setFontHeightInPoints((short) 9);
        rowFont.setFontName(fontName);
        rowFont.setColor(IndexedColors.BLACK.getIndex());

        
        CellStyle rowCellStyle = workbook.createCellStyle();
        rowCellStyle.setFillBackgroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
        rowCellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        rowCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        rowCellStyle.setFont(rowFont);
        rowCellStyle.setBorderTop(BorderStyle.THICK);
        rowCellStyle.setBorderLeft(BorderStyle.NONE);
        rowCellStyle.setBorderRight(BorderStyle.NONE);
        rowCellStyle.setBorderBottom(BorderStyle.THICK);
        rowCellStyle.setWrapText(false);
        rowCellStyle.setAlignment(HorizontalAlignment.CENTER);
		return rowCellStyle;
  

	}

	public CellStyle getHeaderCellStyle(Workbook workbook) throws FileNotFoundException
	{
		try {
	     Font headerFont = workbook.createFont();
	        headerFont.setBold(true);
	        headerFont.setFontHeightInPoints((short) 9);
	        headerFont.setFontName(fontName);
	        headerFont.setColor(IndexedColors.BLACK.getIndex());

	        // Create a CellStyle with the font
	        CellStyle headerCellStyle = workbook.createCellStyle();
	        headerCellStyle.setFont(headerFont);
	        headerCellStyle.setFillBackgroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
	        headerCellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
	        headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	        headerCellStyle.setBorderTop(BorderStyle.THICK);
	        headerCellStyle.setBorderLeft(BorderStyle.THICK);
	        headerCellStyle.setBorderRight(BorderStyle.THICK);
	        headerCellStyle.setBorderBottom(BorderStyle.THICK);
	        headerCellStyle.setAlignment(HorizontalAlignment.CENTER);

	        return headerCellStyle;
		}
	 catch (Exception e) {
        String errorMessage = "Failed to create header cell style for workbook: " + workbook;
        logger.error(errorMessage, e);
        throw new FileNotFoundException(errorMessage);
    }
	        

	}
	public Hyperlink getHyperLinkSheet(CreationHelper createHelper,String sheetName)
	{
		Hyperlink link = createHelper.createHyperlink(HyperlinkType.DOCUMENT);
		link.setAddress("'" + sheetName+"'!A1");
		return link;
	}

	

	public Hyperlink getHyperLinkScreenshot(CreationHelper createHelper,String path)
	{
		Hyperlink link = createHelper.createHyperlink(HyperlinkType.FILE);
		path= path.replace("\\", "/");
		logger.info(path);
		link.setAddress(path);
		return link;
	}

	
	public void closeWorkBook(Workbook workbook, String filePath) throws FileNotFoundException {
	    try (FileOutputStream fileOut = new FileOutputStream(filePath)) {
	        workbook.write(fileOut);
	        workbook.close();
	    } catch (FileNotFoundException e) {
	        String errorMessage = "File not found at path: " + filePath;
	        logger.error(errorMessage, e);
	        throw new FileNotFoundException(errorMessage);
	    }  catch (IOException e) {
	        String errorMessage = "I/O error occurred while closing workbook at path: " + filePath;
	        logger.error(errorMessage, e);
	        throw new FileNotFoundException(errorMessage);
	    } 
	}

	
}