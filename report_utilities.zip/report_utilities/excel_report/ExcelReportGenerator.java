package report_utilities.excel_report;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import report_utilities.constants.ReportContants;
import report_utilities.extent_model.TestCaseDetails;
import report_utilities.extent_model.TestStepDetails;

public class ExcelReportGenerator {

	
	ArrayList<String> browserHeader = new ArrayList<>();
	ArrayList<String> moduleHeader = new ArrayList<>();
	ArrayList<String> testCaseHeader = new ArrayList<>();
	ArrayList<String> testStepHeader = new ArrayList<>();
	ArrayList<Integer> browserHeaderSize = new ArrayList<>();
	ArrayList<Integer> moduleHeaderSize = new ArrayList<>();
	ArrayList<Integer> testCaseHeaderSize = new ArrayList<>();
	ArrayList<Integer> testStepHeaderSize = new ArrayList<>();
	private static final Logger logger =LoggerFactory.getLogger(ExcelReportGenerator.class.getName());
	
	public void initializeColumnHeaders()
	{
		browserHeader.add("S.No");
		browserHeaderSize.add(10*250);
		browserHeader.add("Browser");
		browserHeaderSize.add(20*250);
		browserHeader.add("TotalTestCases");
		browserHeaderSize.add(20*250);
		browserHeader.add("TestCasesPassed");
		browserHeaderSize.add(20*250);
		browserHeader.add("TestCasesFailed");
		browserHeaderSize.add(20*250);
		browserHeader.add("TestCasesSkipped");
		browserHeaderSize.add(20*250);
		
		moduleHeader.add("S.No");
		moduleHeaderSize.add(10*250);
		moduleHeader.add("Module");
		moduleHeaderSize.add(20*250);
		moduleHeader.add("TotalTestCases");
		moduleHeaderSize.add(20*250);
		moduleHeader.add("TestCasesPassed");
		moduleHeaderSize.add(20*250);
		moduleHeader.add("TestCasesFailed");
		moduleHeaderSize.add(20*250);
		moduleHeader.add("TestCasesSkipped");
		moduleHeaderSize.add(20*250);
		
		testCaseHeader.add("S.No");
		testCaseHeaderSize.add(10*250);
		testCaseHeader.add("TestCaseName");
		testCaseHeaderSize.add(20*250);
		testCaseHeader.add("TestCaseDetails");
		testCaseHeaderSize.add(40*250);
		testCaseHeader.add("Module");
		testCaseHeaderSize.add(15*250);
		testCaseHeader.add("TestCaseCategory");
		testCaseHeaderSize.add(25*250);
		testCaseHeader.add("CaseNumber");
		testCaseHeaderSize.add(25*250);
		testCaseHeader.add("ApplicationNumber");
		testCaseHeaderSize.add(25*250);
		testCaseHeader.add("Browser");
		testCaseHeaderSize.add(15*250);
		testCaseHeader.add("Status");
		testCaseHeaderSize.add(15*250);
		testCaseHeader.add("StartTime");
		testCaseHeaderSize.add(25*250);
		testCaseHeader.add("EndTime");
		testCaseHeaderSize.add(25*250);
		testCaseHeader.add("Duration");
		testCaseHeaderSize.add(15*250);
		
		
		testStepHeader.add("S.No");
		testStepHeaderSize.add(10*250);
		testStepHeader.add("TestStepName");
		testStepHeaderSize.add(25*250);
		testStepHeader.add("TestStepDetails");
		testStepHeaderSize.add(40*250);
		testStepHeader.add("Status");
		testStepHeaderSize.add(15*250);
		testStepHeader.add("StartTime");
		testStepHeaderSize.add(25*250);
		testStepHeader.add("EndTime");
		testStepHeaderSize.add(25*250);
		testStepHeader.add("Duration");
		testStepHeaderSize.add(15*250);
		testStepHeader.add("Screenshot");
		testStepHeaderSize.add(15*250);
		testStepHeader.add("ErrorMessage");
		testStepHeaderSize.add(25*250);
		testStepHeader.add("ErrorDetails");
		testStepHeaderSize.add(40*250);
		
		
	}
	
	public void generateExcelReport(List<HashMap<UUID, TestCaseDetails>> testCaseRepository,String filePath) throws IOException
	{
		try {
		initializeColumnHeaders();
		
		ExcelReportCommon excelreport = new ExcelReportCommon();
		
		Workbook workbook=excelreport.createWorkbook();
		
		CreationHelper createHelper= excelreport.createExcelHelper(workbook);
		
		Sheet dashboardSheet= excelreport.createSheet(workbook, "Dashboard");
	
		excelreport.createHeader(workbook, dashboardSheet, moduleHeader,moduleHeaderSize,0);	
	
		excelreport.addTestModuleDetails(workbook, dashboardSheet, ReportContants.getModuleResults());

		ExcelRunSettings.setDashboardRowCounter(ExcelRunSettings.getDashboardRowCounter()+2);
		
		excelreport.createHeader(workbook, dashboardSheet, browserHeader,browserHeaderSize,ExcelRunSettings.getDashboardRowCounter());	
		
		excelreport.addTestBrowserDetails(workbook, dashboardSheet, ReportContants.getBrowserResults());
	
		
		Sheet testcaseDetails= excelreport.createSheet(workbook, "TestCases");

		for (HashMap<UUID, TestCaseDetails> dictTC : testCaseRepository) {
		    Optional<TestCaseDetails> optionalTestCaseDetails = dictTC.values().stream().findFirst();
		    if (optionalTestCaseDetails.isPresent()) {
		        TestCaseDetails testCaseDetails = optionalTestCaseDetails.get();
		        String testcaseName = testCaseDetails.testCaseName;

		        Sheet testStepDetails = excelreport.createSheet(workbook, testcaseName);
		        ExcelRunSettings.getTcSheetMapping().put(testcaseName, testStepDetails);
		    } else {
		        // Handle the case where no TestCaseDetails are found, if necessary
		        // For example, log a warning or throw an exception
		        logger.warn("No TestCaseDetails found in the current dictionary.");
		    }
		}
		excelreport.createHeader(workbook, testcaseDetails, testCaseHeader,testCaseHeaderSize,0);
	
		excelreport.addTestCaseDetails(workbook, testcaseDetails, createHelper,ReportContants.getTestcaseResults());

		if (testCaseRepository != null)
		{

			for (HashMap<UUID, TestCaseDetails> dictTC : testCaseRepository) {
			    // Retrieve the first TestCaseDetails object from the current HashMap safely
			    Optional<TestCaseDetails> optionalTestCaseDetails = dictTC.values().stream().findFirst();

			    if (optionalTestCaseDetails.isPresent()) {
			        TestCaseDetails testCaseDetails = optionalTestCaseDetails.get();
			        String testcaseName = testCaseDetails.testCaseName;

			        // Retrieve the corresponding sheet for the test case name
			        Sheet testStepDetail = ExcelRunSettings.getTcSheetMapping().get(testcaseName);

			        // Create header in the Excel sheet
			        excelreport.createHeader(workbook, testStepDetail, testStepHeader, testStepHeaderSize, 0);

			        // Retrieve the list of test step details
			        List<TestStepDetails> testStepDetails = testCaseDetails.getStepDetails();

			        // Add test step details to the Excel sheet
			        excelreport.addTestStepDetails(workbook, testStepDetail, createHelper, testStepDetails);
			    } else {
			        // Handle the case where no TestCaseDetails object is found
			    	logger.info("No TestCaseDetails found in the current HashMap.");
			    }
			}

		}
		
		excelreport.closeWorkBook(workbook, filePath);

		} catch (Exception e) {
		    // Log the exception with contextual information
		    logger.error("An error occurred while processing test cases: " + e.getMessage(), e);

		    // Rethrow the exception with additional context
		}
		
	}
	
	public void generateExcelReportTestCase(TestCaseDetails testCaseDetails,String filePath) throws FileNotFoundException
	{
		initializeColumnHeaders();
		
		ExcelReportCommon excelreport = new ExcelReportCommon();
		
		Workbook workbook=excelreport.createWorkbook();
		
		CreationHelper createHelper= excelreport.createExcelHelper(workbook);
		

				String testcaseName = testCaseDetails.testCaseName;

				Sheet testStepDetail= excelreport.createSheet(workbook, testcaseName);
				

				excelreport.createHeader(workbook, testStepDetail, testStepHeader,testStepHeaderSize,0);

				List<TestStepDetails> testStepDetails = testCaseDetails.getStepDetails();
				
				excelreport.addTestStepDetails(workbook, testStepDetail, createHelper, testStepDetails);


		excelreport.closeWorkBook(workbook, filePath);

		
		
	}
}