package report_utilities.excel_report;

import org.apache.poi.ss.usermodel.Sheet;

import java.util.HashMap;
import java.util.Map;

public class ExcelRunSettings {

	private ExcelRunSettings() {
		
	}
	private static int dashboardRowCounter=0;
	private static Map<String, Sheet> tcSheetMapping= new HashMap<>();
	public static int getDashboardRowCounter() {
		return dashboardRowCounter;
	}
	public static void setDashboardRowCounter(int dashboardRowCounter) {
		ExcelRunSettings.dashboardRowCounter = dashboardRowCounter;
	}
	public static Map<String, Sheet> getTcSheetMapping() {
		return tcSheetMapping;
	}
	public static void setTcSheetMapping(Map<String, Sheet> tcSheetMapping) {
		ExcelRunSettings.tcSheetMapping = tcSheetMapping;
	}
}