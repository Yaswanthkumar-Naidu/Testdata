package report_utilities.extent_model;

public class PageDetails 
{
	
	private String pageActionName="";
	private String pageActionDescription="";
	public String getPageActionName() {
		return pageActionName;
	}
	public void setPageActionName(String pageActionName) {
		this.pageActionName = pageActionName;
	}
	public String getPageActionDescription() {
		return pageActionDescription;
	}
	public void setPageActionDescription(String pageActionDescription) {
		this.pageActionDescription = pageActionDescription;
	}

}
