package report_utilities.extent_model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.UUID;

public class TestCaseDetails
{
	
	@JsonProperty("TestCaseId")
    public UUID  testCaseId;
	
	@JsonProperty("TestCaseFullName")
    public String testCaseFullName;
	
	@JsonProperty("TestCaseName")
    public String testCaseName;

	@JsonProperty("TestCaseDescription")
    public String testCaseDescription;
	
	@JsonProperty("Module")
    public String module;
	
	@JsonProperty("Browser")
    public String browser;
	
	@JsonProperty("TestCaseCategory")
    public String testCaseCategory;
	
	@JsonProperty("Iteration")
    public int iteration=1;
	
	@JsonProperty("StartTime")
    public LocalDateTime startTime;
	
	@JsonProperty("EndTime")
    public LocalDateTime endTime;
	
	@JsonProperty("Duration")
    public BigDecimal  duration;
	
	@JsonProperty("testCaseStatus")
    public String testCaseStatus = "Unknown";

	@JsonProperty("ErrorMessage")
    public String errorMessage = "";
	
	//******temp changes//
	@JsonProperty("CaseNumber")
    public String caseNumber = "";
	@JsonProperty("ApplicationNumber")
    public String applicationNumber = "";

	public TestCaseDetails() {
	    // This constructor is intentionally left empty.
	    // It is provided to allow the creation of TestCaseDetails objects
	    // without any initial parameters.
	}
    private List<TestStepDetails> stepDetails = new ArrayList<>();

    public UUID  getUniqueTestCaseID()
    {
        testCaseId = UUID.randomUUID();
        return testCaseId;
    }

    public Map<UUID , TestCaseDetails> addNewTestCase(String testcasename, String testCaseFullName,String testcasedescription,
        String module,String testCaseCategory,
         LocalDateTime starttime)
    {

        HashMap<UUID, TestCaseDetails> newTestCase = new HashMap<>();

       testCaseId = UUID.randomUUID();
        TestCaseDetails testCaseDetails = new TestCaseDetails();
        testCaseDetails.testCaseId = testCaseId;
        testCaseDetails.testCaseName = testcasename;
        testCaseDetails.testCaseFullName = testCaseFullName;
        testCaseDetails.testCaseDescription = testcasedescription;
        testCaseDetails.module = module;
        testCaseDetails.browser = browser;

        testCaseDetails.testCaseCategory = testCaseCategory;
        
        //Temp changes//
        testCaseDetails.caseNumber=caseNumber;
        testCaseDetails.applicationNumber=applicationNumber;
        //
       testCaseDetails.iteration = 1;
       
        testCaseDetails.startTime = starttime;

        newTestCase.put(testCaseId, testCaseDetails);
        return newTestCase;
    }

	public List<TestStepDetails> getStepDetails() {
		return stepDetails;
	}

	public void setStepDetails(List<TestStepDetails> stepDetails) {
		this.stepDetails = stepDetails;
	}



}
