package report_utilities.extent_model;


import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;


public class TestRunDetails
{

	@JsonProperty("TestCaseRepository")
	static ArrayList<Map<UUID, TestCaseDetails>> testCaseRepository = new ArrayList<>();
	@JsonProperty("TestCaseMapping")

	static ArrayList<HashMap<String, UUID>> testCaseMapping = new ArrayList<>();


	public static  List<Map<UUID, TestCaseDetails>>  getTestCaseRepository()
	{
		return testCaseRepository;
	}
	
	TestRunDetails()
	{
		//Constructor
		//Constructor
	}

}