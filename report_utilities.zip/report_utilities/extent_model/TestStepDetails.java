package report_utilities.extent_model;

import com.aventstack.extentreports.Status;
import com.fasterxml.jackson.annotation.JsonProperty;

import report_utilities.model.TestStepModel;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class TestStepDetails
{
	public enum TestStepType{MULTI_TC,MODULE,SCREEN,TEST_STEP,VERIFICATION,EXCEPTION,MODULE_SCREEN}
	
	public enum TestStepFormat{PLAIN,HTML,CODE,XML,JSON,TABLE}


	@JsonProperty("StepName")
	public String stepName="" ;
	
	@JsonProperty("StepDescription")
	public String stepDescription="";
	
	@JsonProperty("StartTime")
	public LocalDateTime startTime=LocalDateTime.now();
	
	@JsonProperty("EndTime")
	public LocalDateTime endTime=LocalDateTime.now();
	
	@JsonProperty("Duration")
	public String duration="";
	
	@JsonProperty("testCaseStatus")
	public String testCaseStatus = "";
	
	@JsonProperty("ExtentStatus")
	public Status extentStatus=Status.SKIP;
	
	@JsonProperty("ScreenShotData")
	public String screenShotData = "";
	
	@JsonProperty("ErrorMessage")
	public String errorMessage="";
	
	@JsonProperty("ErrorDetails")
	public String errorDetails="";
	
	@JsonProperty("ActualResponse")
	public String actualResponse="";
	
	@JsonProperty("ExpectedResponse")
	public String expectedResponse="";

	@JsonProperty("ModuleName")
	public String moduleName="";
	
	@JsonProperty("ScreenName")
	public String screenName="";
	
	@JsonProperty("TestStepType")
	public TestStepType testStepType=TestStepType.TEST_STEP;
	
	@JsonProperty("TestStepFormat")
	public TestStepFormat testStepFormat=TestStepFormat.PLAIN;

	TestStepDetails()
	{
		
	}
	public TestStepDetails addTestStepDetails(String teststepname, String testcasedescription,
		LocalDateTime starttime, LocalDateTime endtime, String testStepStatus )
	{

		TestStepDetails testStepDetails = new TestStepDetails();
		testStepDetails.stepName = teststepname;
		testStepDetails.stepDescription = testcasedescription;
		testStepDetails.startTime = starttime;
		testStepDetails.endTime = endtime;
		testStepDetails.duration = String.valueOf(endtime.getSecond()-starttime.getSecond());
		testStepDetails.testCaseStatus = testStepStatus;
		testStepDetails.extentStatus=getExtentStatus(testStepStatus);
		
		return testStepDetails;
	}
	
	public TestStepDetails addTestStepDetails(String teststepname, String testcasedescription,
			LocalDateTime starttime, LocalDateTime endtime, String testStepStatus, String screenshotdata )
		{

		TestStepDetails testStepDetails = new TestStepDetails();
		testStepDetails.stepName = teststepname;
		testStepDetails.stepDescription = testcasedescription;
		testStepDetails.startTime = starttime;
		testStepDetails.endTime = endtime;
		testStepDetails.duration = String.valueOf(endtime.getSecond()-starttime.getSecond());
		testStepDetails.testCaseStatus = testStepStatus;
		testStepDetails.extentStatus=getExtentStatus(testStepStatus);
			testStepDetails.screenShotData = screenshotdata;

			return testStepDetails;
		}

	


	public TestStepDetails addTestStepDetailsPdf(String teststepname, String testcasedescription,
			LocalDateTime starttime, LocalDateTime endtime, String testStepStatus,String results )
	{

		TestStepDetails testStepDetails = new TestStepDetails();
		testStepDetails.stepName = teststepname;
		testStepDetails.stepDescription = testcasedescription;
		testStepDetails.startTime = starttime;
		testStepDetails.endTime = endtime;
		testStepDetails.testCaseStatus = testStepStatus;
		testStepDetails.extentStatus=getExtentStatus(testStepStatus);
		testStepDetails.errorMessage = results;


		return testStepDetails;
	}
	
	public String getStartTime()
	{
	    LocalDateTime today = startTime;
	    DateTimeFormatter format = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:MM:SS.SSS");
	    return today.format(format);
	}
	
	public String getEndTime()
	{
	    LocalDateTime today = endTime;
	    DateTimeFormatter format = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:MM:SS.SSS");
	    return today.format(format);
	}
	
	public Status getExtentStatus(String tcStatus)
	{
		if(tcStatus.equalsIgnoreCase("PASS"))
		{
			return Status.PASS;
		}
		else if(tcStatus.equalsIgnoreCase("FAIL"))
		{
			return Status.FAIL;
		}
		else
		{
			return Status.INFO;
		}

	}
	
	public TestStepType getTestStepType(TestStepModel.TestStepType testStepType)
	{
		switch(testStepType)
		{
		case Module:
			return TestStepType.MODULE;
			
		case Module_Screen:
			return TestStepType.MODULE_SCREEN;
			
		case MultiTC:
			return TestStepType.MULTI_TC;
			
		case Screen:
			return TestStepType.SCREEN;
			
		case TestStep:
			return TestStepType.TEST_STEP;

		case Verification:
			return TestStepType.VERIFICATION;

		case Exception:
			return TestStepType.EXCEPTION;
		
		
		default:
				return TestStepType.TEST_STEP;	
		}
		
	}
	
	public TestStepFormat getTestStepFormat(TestStepModel.TestStepFormat testStepFormat)
	{
		switch(testStepFormat)
		{
		case Plain:
			return TestStepFormat.PLAIN;
			

		case HTML:
			return TestStepFormat.HTML;
			
		case Code:
			return TestStepFormat.CODE;
			
		case XML:
			return TestStepFormat.XML;
			
		case JSON:
			return TestStepFormat.JSON;
				
		case Table:
			return TestStepFormat.TABLE;
			
		
		default:
				return TestStepFormat.PLAIN;	
		}
		
	}
	
	public TestStepDetails getTestStepDetails()
	{
		return new TestStepDetails();
		
	}
	private static String formatDuration(LocalDateTime startTime,LocalDateTime endTime) {
		java.time.Duration duration= java.time.Duration.between(startTime, endTime);
        long hours = duration.toHours();
        long minutes = duration.toMinutesPart();
        long seconds = duration.toSecondsPart();

        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }
	public String getStepName() {
		return stepName;
	}
	public void setStepName(String stepName) {
		this.stepName = stepName;
	}
	public String getStepDescription() {
		return stepDescription;
	}
	public void setStepDescription(String stepDescription) {
		this.stepDescription = stepDescription;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getTestCaseStatus() {
		return testCaseStatus;
	}
	public void setTestCaseStatus(String testCaseStatus) {
		this.testCaseStatus = testCaseStatus;
	}
	public Status getExtentStatus() {
		return extentStatus;
	}
	public void setExtentStatus(Status extentStatus) {
		this.extentStatus = extentStatus;
	}
	public String getScreenShotData() {
		return screenShotData;
	}
	public void setScreenShotData(String screenShotData) {
		this.screenShotData = screenShotData;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getErrorDetails() {
		return errorDetails;
	}
	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}
	public String getActualResponse() {
		return actualResponse;
	}
	public void setActualResponse(String actualResponse) {
		this.actualResponse = actualResponse;
	}
	public String getExpectedResponse() {
		return expectedResponse;
	}
	public void setExpectedResponse(String expectedResponse) {
		this.expectedResponse = expectedResponse;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public String getScreenName() {
		return screenName;
	}
	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}
	public TestStepType getTestStepType() {
		return testStepType;
	}
	public void setTestStepType(TestStepModel.TestStepType testStepType) {
		this.testStepType = getTestStepType(testStepType);
	}
	

	public TestStepFormat getTestStepFormat() {
		return testStepFormat;
	}
	public void setTestStepFormat(TestStepModel.TestStepFormat testStepFormat) {
		this.testStepFormat = getTestStepFormat(testStepFormat);
	}
	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}
	public void setEndTime(LocalDateTime endTime) {
		this.endTime = endTime;
	}
	
	
	
}