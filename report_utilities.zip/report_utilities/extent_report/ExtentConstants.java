package report_utilities.extent_report;

public class ExtentConstants
{
    public enum TestStepStatus { PASS, FAIL, DONE,SKIP }
}