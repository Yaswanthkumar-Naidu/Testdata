package report_utilities.extent_report;


public class ExtentTestSteps
 {
     private String testStepName;
     private String testStepDesc;
     private ExtentConstants.TestStepStatus testStepStatus;

     public ExtentConstants.TestStepStatus getTestStepStatus()
     {
         return testStepStatus;
     }

     public void setTestStepStatus(ExtentConstants.TestStepStatus testStepStatus)
     {
         this.testStepStatus = testStepStatus;
     }

     public String getTestStepName()
     {
         return testStepName;
     }

     public void setTestStepName(String testStepName)
     {
         this.testStepName = testStepName;
     }


     public String getTestStepDesc()
     {
         return testStepDesc;
     }

     public void setTestStepDesc(String testStepDesc)
     {
         this.testStepDesc = testStepDesc;
     }
 }