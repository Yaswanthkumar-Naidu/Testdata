package report_utilities.html_model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class HTMLTCLiveModel {

	@JsonProperty("TestCase")
	public String testCase="";
	@JsonProperty("Module")
	public String module="";
	@JsonProperty("Browser")
	public String browser="";
	@JsonProperty("Status")
	public String status="";
	@JsonProperty("FilePath")
	public String filePath="";
	
	
	public HTMLTCLiveModel()
	{
		//asasa
		//asasa
	}

	public HTMLTCLiveModel addDataHtmlTCLiveModel(String testCase,String moduleName, String browser, String status,String tcFilePath)
	{
		HTMLTCLiveModel htmltcLiveModel =new HTMLTCLiveModel();
		htmltcLiveModel.testCase=testCase;
		htmltcLiveModel.module=moduleName;
		htmltcLiveModel.browser=browser;
		htmltcLiveModel.status=status;
		htmltcLiveModel.filePath=tcFilePath;

		return htmltcLiveModel;
	}

	
	public String getTestCase() {
	
		return testCase;
	}
	
	public String getModule() {
		
		return module;
	}
	
	
	public String getBrowser() {
		
		return browser;
	}
	
	public String getStatus() {
		
		return status;
	}
	
	public String getFilePath() {
		
		return filePath;
	}
	
	
	public void setStatus(String status)
	{
		this.status=status;
	}
	
}
