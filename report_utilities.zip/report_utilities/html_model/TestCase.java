package report_utilities.html_model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

public class TestCase {
	@JsonProperty("testCaseName")
    private String testCaseName;
	
	@JsonProperty("module")
    private String module;
	
	@JsonProperty("browser")
    private String browser;
	
	@JsonProperty("status")
    private String status;
    
	@JsonProperty("totalSteps")
	private int totalSteps=0;
    
	@JsonProperty("passed")
    private int passed;
	
	@JsonProperty("failed")
    private int failed;
	
	@JsonProperty("startTime")
    private String startTime;
	
	@JsonProperty("endTime")
    private String endTime;
   
	@JsonProperty("duration")
    private String duration;

	
	@JsonProperty("testSteps")
	 private List<TestStep> testSteps= new  ArrayList<>();
	
	@JsonProperty("currentStepData")
	    private CurrentStepData currentStepData= new CurrentStepData();
	

	public TestCase()
    {
    	
    }
    
	public TestCase(String testCaseName, String module, String browser, String status) {
        this.testCaseName = testCaseName;
        this.module = module;
        this.browser = browser;
        this.status = status;
    }


	

    
	/**
	 * @return the testCaseName
	 */
	public String getTestCaseName() {
		return testCaseName;
	}
	/**
	 * @param testCaseName the testCaseName to set
	 */
	public void setTestCaseName(String testCaseName) {
		this.testCaseName = testCaseName;
	}
	/**
	 * @return the module
	 */
	public String getModule() {
		return module;
	}
	/**
	 * @param module the module to set
	 */
	public void setModule(String module) {
		this.module = module;
	}
	/**
	 * @return the browser
	 */
	public String getBrowser() {
		return browser;
	}
	/**
	 * @param browser the browser to set
	 */
	public void setBrowser(String browser) {
		this.browser = browser;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	 
    /**
	 * @return the totalSteps
	 */
	public int getTotalSteps() {
		return totalSteps;
	}

	/**
	 * @param totalSteps the totalSteps to set
	 */
	public void setTotalSteps(int totalSteps) {
		this.totalSteps = totalSteps;
	}

	/**
	 * @return the passed
	 */
	public int getPassed() {
		return passed;
	}

	/**
	 * @param passed the passed to set
	 */
	public void setPassed(int passed) {
		this.passed = passed;
	}

	/**
	 * @return the failed
	 */
	public int getFailed() {
		return failed;
	}

	/**
	 * @param failed the failed to set
	 */
	public void setFailed(int failed) {
		this.failed = failed;
	}

	/**
	 * @return the startTime
	 */
	public String getStartTime() {
		return startTime;
	}

	/**
	 * @param startTime the startTime to set
	 */
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	/**
	 * @return the endTime
	 */
	public String getEndTime() {
		return endTime;
	}

	/**
	 * @param endTime the endTime to set
	 */
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	/**
	 * @return the duration
	 */
	public String getDuration() {
		return duration;
	}

	/**
	 * @param duration the duration to set
	 */
	public void setDuration(String duration) {
		this.duration = duration;
	}
	
	
	public List<TestStep> getTestSteps() {
        return testSteps;
    }

    public void setTestSteps(List<TestStep> testSteps) {
        this.testSteps = testSteps;
    }

    public CurrentStepData getCurrentStepData() {
        return currentStepData;
    }

    public void setCurrentStepData(CurrentStepData currentStepData) {
        this.currentStepData = currentStepData;
    }
}
