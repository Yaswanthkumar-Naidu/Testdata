package report_utilities.html_report;

import report_utilities.constants.HTMLReportContants;

public class InitializeHTMLReports {

	
	
	public void initHTMLReports(String prjPath,String reportPath) throws InterruptedException
	{
		HTMLReportContants.setHtmlreportsdir(reportPath+HTMLReportContants.HTML_REPORTS_DIR_NAME);
		HTMLReports htmlReports= new HTMLReports();
		String fileLocation=prjPath+"/"+ HTMLReportContants.HTML_FILE_LOCATION;
		HTMLReportContants.setPlaceHolderHTMLIndex(htmlReports.readDataFromTextFile(fileLocation + HTMLReportContants.TEMPLATE_HTML_INDEX));
		HTMLReportContants.setPlaceHolderScreenShot(htmlReports.readDataFromTextFile(fileLocation + HTMLReportContants.TEMPLATE_SCREEN_SHOT));
		HTMLReportContants.setPlaceHolderHTMLTestCase(htmlReports.readDataFromTextFile(fileLocation + HTMLReportContants.TEMPLATE_HTML_TEST_CASE));
		HTMLReportContants.setPlaceHolderTestStepPre(htmlReports.readDataFromTextFile(fileLocation + HTMLReportContants.TEMPLATE_TEST_STEP_PRE));
		HTMLReportContants.setPlaceHolderCurrentTestStep(htmlReports.readDataFromTextFile(fileLocation + HTMLReportContants.TEMPLATE_CURRENT_TEST_STEP));
		HTMLReportContants.setPlaceHolderHTMLSummary(htmlReports.readDataFromTextFile(fileLocation + HTMLReportContants.TEMPLATE_HTML_SUMMARY));
		HTMLReportContants.setPlaceHolderHTMLSummaryBrowserRow(htmlReports.readDataFromTextFile(fileLocation + HTMLReportContants.TEMPLATE_HTML_SUMMARY_MODULE_BROWSER_ROW));
		HTMLReportContants.setPlaceHolderHTMLSummaryModuleRow(htmlReports.readDataFromTextFile(fileLocation + HTMLReportContants.TEMPLATE_HTML_SUMMARY_MODULE_BROWSER_ROW));
		HTMLReportContants.setPlaceHolderHTMLSummaryTCRow(htmlReports.readDataFromTextFile(fileLocation + HTMLReportContants.TEMPLATE_HTML_SUMMARY_TC_ROW));
Thread.sleep(0);
		HTMLReportContants.setPlaceHolderHTMLTCLiveRow(htmlReports.readDataFromTextFile(fileLocation + HTMLReportContants.TEMPLATE_HTMLTC_LIVE_ROW));
		HTMLReportContants.setPlaceHolderHTMLTCLiveTemplate(htmlReports.readDataFromTextFile(fileLocation + HTMLReportContants.TEMPLATE_HTMLTC_LIVE_TEMPLATE));

		
		HTMLReportContants.setSummaryDataHTML(htmlReports.readDataFromTextFile(fileLocation + HTMLReportContants.SUMMARY_DASHBOARD));
		HTMLReportContants.setSummaryDataCSS(htmlReports.readFileLineByLine(fileLocation + HTMLReportContants.SUMMARY_CSS));
		HTMLReportContants.setHtmlSummaryDataJS(htmlReports.readFileLineByLine(fileLocation + HTMLReportContants.SUMMARY_JS));
		
		HTMLReportContants.setTestCaseDataHTML(htmlReports.readDataFromTextFile(fileLocation + HTMLReportContants.TEST_CASE_HTML));
		HTMLReportContants.setTestCaseDataCSS(htmlReports.readFileLineByLine(fileLocation + HTMLReportContants.TEST_CASE_CSS));
		HTMLReportContants.setTestCaseDataJS(htmlReports.readFileLineByLine(fileLocation + HTMLReportContants.TCSCRIPT_JS));

		HTMLReportContants.setSummaryJSONFilePath(HTMLReportContants.getHtmlreportsdir() + HTMLReportContants.SUMMARY_JSON);

		
	}
}