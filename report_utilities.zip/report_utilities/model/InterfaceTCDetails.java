package report_utilities.model;

import java.time.LocalDateTime;

import report_utilities.extent_report.ExtentConstants.TestStepStatus;

public class InterfaceTCDetails
{
    private long testRunId;
    private String testCaseId;
    private String module;
    private int iteration;
    private String interfaceName = "";
    private String requestData;
    private String responseData;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private int duration;
    private String tcStatus = "";
    private TestStepStatus testCaseStatus;
    private String statusCode = "";
    private String errorMessage = "";
    private String fileFormat = "";


    public TestStepStatus setTestCaseStatus(String tcStatus)
    {
        try
        {
        	if (tcStatus.toUpperCase().equalsIgnoreCase("PASS"))
            {
                testCaseStatus = TestStepStatus.PASS;
            }
            else if (tcStatus.toUpperCase().equalsIgnoreCase("PASSED"))
            {
                testCaseStatus = TestStepStatus.PASS;
            }
            else if (tcStatus.toUpperCase().equalsIgnoreCase("FAIL"))
            {
                testCaseStatus = TestStepStatus.FAIL;
            }
            else if (tcStatus.toUpperCase().equalsIgnoreCase("FAILED"))
            {
                testCaseStatus = TestStepStatus.FAIL;
            }
            else
            {
                testCaseStatus = TestStepStatus.SKIP;
            }
        }
        catch (Exception e)
        {
            testCaseStatus = TestStepStatus.SKIP;
        }

        return testCaseStatus;


    }

    public TestStepStatus getTestCaseStatus()
    {
        return testCaseStatus;
    }

	public long getTestRunId() {
		return testRunId;
	}

	public void setTestRunId(long testRunId) {
		this.testRunId = testRunId;
	}

	public String getTestCaseId() {
		return testCaseId;
	}

	public void setTestCaseId(String testCaseId) {
		this.testCaseId = testCaseId;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public int getIteration() {
		return iteration;
	}

	public void setIteration(int iteration) {
		this.iteration = iteration;
	}

	public String getInterfaceName() {
		return interfaceName;
	}

	public void setInterfaceName(String interfaceName) {
		this.interfaceName = interfaceName;
	}

	public String getRequestData() {
		return requestData;
	}

	public void setRequestData(String requestData) {
		this.requestData = requestData;
	}

	public String getResponseData() {
		return responseData;
	}

	public void setResponseData(String responseData) {
		this.responseData = responseData;
	}

	public LocalDateTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}

	public LocalDateTime getEndTime() {
		return endTime;
	}

	public void setEndTime(LocalDateTime endTime) {
		this.endTime = endTime;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getTcStatus() {
		return tcStatus;
	}

	public void setTcStatus(String tcStatus) {
		this.tcStatus = tcStatus;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getFileFormat() {
		return fileFormat;
	}

	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}
    }