package report_utilities.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class InterfaceTestRun
{
    private long testRunId;
    private String testRunName;
    private String environment;
    private LocalDateTime testRunDate;

    private List<InterfaceTCDetails> interfaceTCDetails = new ArrayList<>();
    private String executedBy;
    private boolean shareAttachmentForPassedTestCases=false;

    public void setInterfaceTestRun(long testRunId,String environment, String testRunName)
    {
        this.testRunId = testRunId;
        this.setEnvironment(environment);
        this.setTestRunName(testRunName);
        setTestRunDate(LocalDateTime.now());
    }

    public long getTestRunId()
    {
        return testRunId;
    }

	public String getTestRunName() {
		return testRunName;
	}

	public void setTestRunName(String testRunName) {
		this.testRunName = testRunName;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public LocalDateTime getTestRunDate() {
		return testRunDate;
	}

	public void setTestRunDate(LocalDateTime testRunDate) {
		this.testRunDate = testRunDate;
	}

	public List<InterfaceTCDetails> getInterfaceTCDetails() {
		return interfaceTCDetails;
	}

	public void setInterfaceTCDetails(List<InterfaceTCDetails> interfaceTCDetails) {
		this.interfaceTCDetails = interfaceTCDetails;
	}

	public String getExecutedBy() {
		return executedBy;
	}

	public void setExecutedBy(String executedBy) {
		this.executedBy = executedBy;
	}

	public boolean isShareAttachmentForPassedTestCases() {
		return shareAttachmentForPassedTestCases;
	}

	public void setShareAttachmentForPassedTestCases(boolean shareAttachmentForPassedTestCases) {
		this.shareAttachmentForPassedTestCases = shareAttachmentForPassedTestCases;
	}
}
