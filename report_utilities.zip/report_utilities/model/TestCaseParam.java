package report_utilities.model;

public class TestCaseParam
{
	public enum TestCaseType {Prereq,Main}
	private String testCaseName ;
	private String testCaseDescription ;
	private String moduleName ;
    private String testCaseCategory;
    private TestCaseType testCaseType= TestCaseType.Main;
  
    ///*******temp changes8888////
    private String caseNumber ;
    private String applicationNumber ;
    
    
    
    ///**************************//



    private int iteration = 1;
    private String browser;
	private String apiName;
	public String getTestCaseName() {
		return testCaseName;
	}
	public void setTestCaseName(String testCaseName) {
		this.testCaseName = testCaseName;
	}
	public String getTestCaseDescription() {
		return testCaseDescription;
	}
	public void setTestCaseDescription(String testCaseDescription) {
		this.testCaseDescription = testCaseDescription;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public String getTestCaseCategory() {
		return testCaseCategory;
	}
	public void setTestCaseCategory(String testCaseCategory) {
		this.testCaseCategory = testCaseCategory;
	}
	public int getIteration() {
		return iteration;
	}
	public void setIteration(int iteration) {
		this.iteration = iteration;
	}
	public String getBrowser() {
		return browser;
	}
	public void setBrowser(String browser) {
		this.browser = browser;
	}
	public String getApiName() {
		return apiName;
	}
	public void setApiName(String apiName) {
		this.apiName = apiName;
	}
	public String getCaseNumber() {
		return caseNumber;
	}
	public void setCaseNumber(String caseNumber) {
		this.caseNumber = caseNumber;
	}
	public String getApplicationNumber() {
		return applicationNumber;
	}
	public void setApplicationNumber(String applicationNumber) {
		this.applicationNumber = applicationNumber;
	}
	public TestCaseType getTestCaseType() {
		return testCaseType;
	}
	public void setTestCaseType(TestCaseType testCaseType) {
		this.testCaseType = testCaseType;
	}

}
