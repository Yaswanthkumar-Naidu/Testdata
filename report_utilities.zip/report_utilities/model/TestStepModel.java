package report_utilities.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TestStepModel
{
	
	public enum TestStepType{MultiTC,Module,Screen,TestStep,Verification,Exception,Module_Screen}
	public enum TestStepFormat{Plain,HTML,Code,XML,JSON,Table}


	
	private TestStepType testStepType=TestStepType.TestStep;
	private TestStepFormat testStepFormat=TestStepFormat.Plain;
	private String testStepName="";
	private String testStepDescription="";
	private LocalDateTime startTime=LocalDateTime.now();
	private LocalDateTime endTime=LocalDateTime.now();
	private String testStepStatus="";
	private String screenShotData="";
	private String duration="";
	private String errorMessage="";
	private String errorDetails="";
	private String actualResponse="";
	private String expectedResponse="";
	private String[][] stepTableData=new String[100][100];
	private String[][] actualTableData=new String[100][100];
	private String[][] expectedTableData=new String[100][100];
	private String moduleName="";
	private String screenName="";
	
	
	
	
	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}
	public void setEndTime(LocalDateTime endTime) {
		this.endTime = endTime;
	}
	private static String formatDuration(LocalDateTime startTime,LocalDateTime endTime) {
		java.time.Duration duration= java.time.Duration.between(startTime, endTime);
        long hours = duration.toHours();
        long minutes = duration.toMinutesPart();
        long seconds = duration.toSecondsPart();

        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }
	public TestStepModel addTestStepDetails(String teststepname, String testcasedescription,
		LocalDateTime starttime, LocalDateTime endtime, String testStepStatus )
	{

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		TestStepModel testStepDetails = new TestStepModel();
		testStepDetails.setTestStepName(teststepname);
		testStepDetails.setTestStepDescription(testcasedescription);
		testStepDetails.startTime = starttime;
		testStepDetails.endTime = endtime;
		testStepDetails.setDuration(formatDuration(starttime, endtime));
		testStepDetails.setTestStepStatus(testStepStatus);
		testStepDetails.setTestStepType(TestStepType.TestStep);
		testStepDetails.setTestStepFormat(TestStepFormat.Plain);
		return testStepDetails;
	}
	
	public TestStepModel addTestStepDetails(String teststepname, String testcasedescription,
			LocalDateTime starttime, LocalDateTime endtime, String testStepStatus, String screenshotdata )
		{

			TestStepModel testStepDetails = new TestStepModel();
			testStepDetails.setTestStepName(teststepname);
			testStepDetails.setTestStepDescription(testcasedescription);
			testStepDetails.startTime = starttime;
			testStepDetails.endTime = endtime;
			testStepDetails.setDuration(formatDuration(starttime, endtime));
			testStepDetails.setTestStepStatus(testStepStatus);
			testStepDetails.setScreenShotData(screenshotdata);
			testStepDetails.setTestStepType(TestStepType.TestStep);
			testStepDetails.setTestStepFormat(TestStepFormat.Plain);

			return testStepDetails;
		}
	
	


	public TestStepModel addTestStepDetails(String teststepname, String testcasedescription,
			LocalDateTime starttime, LocalDateTime endtime, String testStepStatus, String screenshotdata,String format )
		{

			TestStepModel testStepDetails = new TestStepModel();
			testStepDetails.setTestStepName(teststepname);
			testStepDetails.setTestStepDescription(testcasedescription);
			testStepDetails.startTime = starttime;
			testStepDetails.endTime = endtime;
			testStepDetails.setDuration(formatDuration(starttime, endtime));
			testStepDetails.setTestStepStatus(testStepStatus);
			testStepDetails.setScreenShotData(screenshotdata);
			testStepDetails.setTestStepType(TestStepType.TestStep);
			
			testStepDetails.setTestStepFormat(getTestStepFormat(format));
			return testStepDetails;
		}

	
	public TestStepModel addTestStepErrorDetails(String teststepname, String testcasedescription,
			LocalDateTime starttime, LocalDateTime endtime, String testStepStatus, String screenshotdata,String errormessage,String errordetails )
		{

			TestStepModel testStepDetails = new TestStepModel();
			testStepDetails.setTestStepName(teststepname);
			testStepDetails.setTestStepDescription(testcasedescription);
			testStepDetails.startTime = starttime;
			testStepDetails.endTime = endtime;
			testStepDetails.setDuration(formatDuration(starttime, endtime));
			testStepDetails.setTestStepStatus(testStepStatus);
			testStepDetails.setScreenShotData(screenshotdata);
			testStepDetails.setErrorMessage(errormessage);
			testStepDetails.setErrorDetails(errordetails);
			testStepDetails.setTestStepType(TestStepType.Exception);
			testStepDetails.setTestStepFormat(TestStepFormat.Plain);

			return testStepDetails;
		}

	
	public TestStepModel addVerificationStep(String teststepname, String testcasedescription,
			LocalDateTime starttime, LocalDateTime endtime, String testStepStatus, String screenshotdata,String ExpectedResponse,String ActualResponse )
		{

			TestStepModel testStepDetails = new TestStepModel();
			testStepDetails.setTestStepName(teststepname);
			testStepDetails.setTestStepDescription(testcasedescription);
			testStepDetails.startTime = starttime;
			testStepDetails.endTime = endtime;
			testStepDetails.setDuration(formatDuration(starttime, endtime));
			testStepDetails.setTestStepStatus(testStepStatus);
			testStepDetails.setScreenShotData(screenshotdata);
			testStepDetails.setExpectedResponse(ExpectedResponse);
			testStepDetails.setActualResponse(ActualResponse);
			
			testStepDetails.setTestStepType(TestStepType.Verification);
			testStepDetails.setTestStepFormat(TestStepFormat.Plain);

			return testStepDetails;
		}
	
	public TestStepModel addAPITestStep( String stepName, String description,
			LocalDateTime starttime, LocalDateTime endtime, String status,
            String actualResponse, String expectedResponse) {
		
		TestStepModel testStepDetails = new TestStepModel();
		testStepDetails.setTestStepName(stepName);
		testStepDetails.setTestStepDescription(description);
		testStepDetails.startTime = starttime;
		testStepDetails.endTime = endtime;
		testStepDetails.setDuration(formatDuration(starttime, endtime));
		testStepDetails.setTestStepStatus(status);

		testStepDetails.setExpectedResponse(actualResponse);
		testStepDetails.setActualResponse(expectedResponse);
		
		testStepDetails.setTestStepType(TestStepType.Verification);
		testStepDetails.setTestStepFormat(TestStepFormat.Plain);

		return testStepDetails;

	}

	

	
	public TestStepModel AddVerificationStep(String teststepname, String testcasedescription,
            LocalDateTime starttime, LocalDateTime endtime, String testStepStatus, String ExpectedResponse,String ActualResponse )
     {

            TestStepModel testStepDetails = new TestStepModel();
            testStepDetails.setTestStepName(teststepname);
            testStepDetails.setTestStepDescription(testcasedescription);
            testStepDetails.startTime = starttime;
            testStepDetails.endTime = endtime;
            testStepDetails.setDuration(formatDuration(starttime, endtime));
            testStepDetails.setTestStepStatus(testStepStatus);
            testStepDetails.setExpectedResponse(ExpectedResponse);
            testStepDetails.setActualResponse(ActualResponse);
            
            testStepDetails.setTestStepType(TestStepType.Verification);
            testStepDetails.setTestStepFormat(TestStepFormat.Plain);

            return testStepDetails;
     }

	
	
	
	public TestStepModel AddVerificationStep(String teststepname, String testcasedescription,
			LocalDateTime starttime, LocalDateTime endtime, String testStepStatus, String screenshotdata,String ExpectedResponse,String ActualResponse,String Format )
		{

			TestStepModel testStepDetails = new TestStepModel();
			testStepDetails.setTestStepName(teststepname);
			testStepDetails.setTestStepDescription(testcasedescription);
			testStepDetails.startTime = starttime;
			testStepDetails.endTime = endtime;
			testStepDetails.setDuration(formatDuration(starttime, endtime));
			testStepDetails.setTestStepStatus(testStepStatus);
			testStepDetails.setScreenShotData(screenshotdata);
			testStepDetails.setExpectedResponse(ExpectedResponse);
			testStepDetails.setActualResponse(ActualResponse);
			testStepDetails.setTestStepType(TestStepType.Verification);
			testStepDetails.setTestStepFormat(getTestStepFormat(Format));

			return testStepDetails;
		}
	
	


	public TestStepModel VerifyTableData(String teststepname, String testcasedescription,
			LocalDateTime starttime, LocalDateTime endtime, String testStepStatus,  String screenshotdata,String[][] ExpectedTableData,String[][] ActualTableData )
		{

			TestStepModel testStepDetails = new TestStepModel();
			testStepDetails.setTestStepName(teststepname);
			testStepDetails.setTestStepDescription(testcasedescription);
			testStepDetails.startTime = starttime;
			testStepDetails.endTime =endtime;
			testStepDetails.setDuration(formatDuration(starttime, endtime));
			testStepDetails.setTestStepStatus(testStepStatus);
			testStepDetails.setScreenShotData(screenshotdata);
			testStepDetails.setExpectedTableData(ExpectedTableData);
			testStepDetails.setActualTableData(ActualTableData);
			testStepDetails.setTestStepType(TestStepType.Verification);
			testStepDetails.setTestStepFormat(TestStepFormat.Table);

			return testStepDetails;
		}



	

	public TestStepModel AddTableData(String teststepname, String testcasedescription,
			LocalDateTime starttime, LocalDateTime endtime, String testStepStatus,  String screenshotdata,String[][] StepTableData )
		{

			TestStepModel testStepDetails = new TestStepModel();
			testStepDetails.setTestStepName(teststepname);
			testStepDetails.setTestStepDescription(testcasedescription);
			testStepDetails.startTime = starttime;
			testStepDetails.endTime = endtime;
			testStepDetails.setDuration(formatDuration(starttime, endtime));
			testStepDetails.setTestStepStatus(testStepStatus);
			testStepDetails.setScreenShotData(screenshotdata);
			testStepDetails.setExpectedTableData(StepTableData);
			testStepDetails.setTestStepType(TestStepType.TestStep);
			testStepDetails.setTestStepFormat(TestStepFormat.Table);

			return testStepDetails;
		}

	
	
	public TestStepModel addModuleScreenData(String moduleName, String screenName)
		{

			TestStepModel testStepDetails = new TestStepModel();
			testStepDetails.startTime = LocalDateTime.now();
			testStepDetails.endTime = LocalDateTime.now();
			testStepDetails.setDuration("");
			testStepDetails.setModuleName(moduleName);
			testStepDetails.setScreenName(screenName);
			testStepDetails.setTestStepType(TestStepType.Module_Screen);
			testStepDetails.setTestStepFormat(TestStepFormat.Plain);

			return testStepDetails;
		}

	
	public TestStepModel addModuleData(String moduleName)
	{

		TestStepModel testStepDetails = new TestStepModel();
		testStepDetails.startTime = LocalDateTime.now();
		testStepDetails.endTime = LocalDateTime.now();
		testStepDetails.setDuration("");
		testStepDetails.setModuleName(moduleName);
		testStepDetails.setTestStepType(TestStepType.Module);
		testStepDetails.setTestStepFormat(TestStepFormat.Plain);

		return testStepDetails;
	}
	
	public TestStepModel addScreenData( String screenName)
	{

		TestStepModel testStepDetails = new TestStepModel();
		testStepDetails.startTime = LocalDateTime.now();
		testStepDetails.endTime = LocalDateTime.now();
		testStepDetails.setDuration("");
		testStepDetails.setScreenName(screenName);
		testStepDetails.setTestStepType(TestStepType.Screen);
		testStepDetails.setTestStepFormat(TestStepFormat.Plain);

		return testStepDetails;
	}

	
	public TestStepModel AddMultiTCData(String TestCaseName)
	{

		TestStepModel testStepDetails = new TestStepModel();
		testStepDetails.startTime = LocalDateTime.now();
		testStepDetails.endTime = LocalDateTime.now();
		testStepDetails.setDuration("");
		testStepDetails.setTestStepName(TestCaseName);
		testStepDetails.setTestStepType(TestStepType.MultiTC);
		testStepDetails.setTestStepFormat(TestStepFormat.Plain);

		return testStepDetails;
	}
	
	public TestStepModel AddVerificationStepPDF(String teststepname, String testcasedescription,
            LocalDateTime starttime, LocalDateTime endtime, String testStepStatus, String Result)
     {
            TestStepModel testStepDetails = new TestStepModel();
            testStepDetails.setTestStepName(teststepname);
            testStepDetails.setTestStepDescription(testcasedescription);
            testStepDetails.startTime = starttime;
            testStepDetails.endTime = endtime;
            testStepDetails.setDuration(formatDuration(starttime, endtime));
            testStepDetails.setTestStepStatus(testStepStatus);
            testStepDetails.setErrorMessage(Result);
            testStepDetails.setTestStepType(TestStepType.Verification);
            testStepDetails.setTestStepFormat(TestStepFormat.Plain);

            return testStepDetails;
     }
	
	public TestStepModel AddVerificationStepPDFPass(String teststepname, String testcasedescription,
            LocalDateTime starttime, LocalDateTime endtime, String testStepStatus)
     {

            TestStepModel testStepDetails = new TestStepModel();
            testStepDetails.setTestStepName(teststepname);
            testStepDetails.setTestStepDescription(testcasedescription);
            testStepDetails.startTime = starttime;
            testStepDetails.endTime = endtime;
            testStepDetails.setDuration(formatDuration(starttime, endtime));
            testStepDetails.setTestStepStatus(testStepStatus);
            testStepDetails.setTestStepType(TestStepType.Verification);
            testStepDetails.setTestStepFormat(TestStepFormat.Plain);

            return testStepDetails;
     }

	
	public TestStepFormat getTestStepFormat(String Format)
	{
		if(Format.equalsIgnoreCase("XML"))
		{
			return TestStepFormat.XML;
		}
		else if(Format.equalsIgnoreCase("JSON"))
		{
			return TestStepFormat.JSON;
		}
		else if(Format.equalsIgnoreCase("CODE"))
		{
			return TestStepFormat.Code;
		}
		else if(Format.equalsIgnoreCase("HTML"))
		{
			return TestStepFormat.HTML;
		}
		else if(Format.equalsIgnoreCase("TABLE"))
		{
			return TestStepFormat.Table;
		}
		else
		{
			return TestStepFormat.Plain;
		}

	}
	
	public LocalDateTime getStartTime()
	{
//	    LocalDateTime today = startTime;
//	    DateTimeFormatter format = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:MM:SS.SSS");
//	    return today.format(format);
		return startTime;
	}
	
	public LocalDateTime getEndTime()
	{
//	    LocalDateTime today = endTime;
//	    DateTimeFormatter format = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:MM:SS.SSS");
//	    return today.format(format);
		return endTime;
	}
	public TestStepType getTestStepType() {
		return testStepType;
	}
	public void setTestStepType(TestStepType testStepType) {
		this.testStepType = testStepType;
	}
	public TestStepFormat getTestStepFormat() {
		return testStepFormat;
	}
	public void setTestStepFormat(TestStepFormat testStepFormat) {
		this.testStepFormat = testStepFormat;
	}
	public String getTestStepName() {
		return testStepName;
	}
	public void setTestStepName(String testStepName) {
		this.testStepName = testStepName;
	}
	public String getTestStepDescription() {
		return testStepDescription;
	}
	public void setTestStepDescription(String testStepDescription) {
		this.testStepDescription = testStepDescription;
	}
	public String getTestStepStatus() {
		return testStepStatus;
	}
	public void setTestStepStatus(String testStepStatus) {
		this.testStepStatus = testStepStatus;
	}
	public String getScreenShotData() {
		return screenShotData;
	}
	public void setScreenShotData(String screenShotData) {
		this.screenShotData = screenShotData;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getErrorDetails() {
		return errorDetails;
	}
	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}
	public String getActualResponse() {
		return actualResponse;
	}
	public void setActualResponse(String actualResponse) {
		this.actualResponse = actualResponse;
	}
	public String getExpectedResponse() {
		return expectedResponse;
	}
	public void setExpectedResponse(String expectedResponse) {
		this.expectedResponse = expectedResponse;
	}
	public String[][] getActualTableData() {
		return actualTableData;
	}
	public void setActualTableData(String[][] actualTableData) {
		this.actualTableData = actualTableData;
	}
	public String[][] getExpectedTableData() {
		return expectedTableData;
	}
	public void setExpectedTableData(String[][] expectedTableData) {
		this.expectedTableData = expectedTableData;
	}
	public String[][] getStepTableData() {
		return stepTableData;
	}
	public void setStepTableData(String[][] stepTableData) {
		this.stepTableData = stepTableData;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public String getScreenName() {
		return screenName;
	}
	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}
}
