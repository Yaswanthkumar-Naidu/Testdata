package report_utilities.test_result_model;

public class BrowserResult {
	
	private String browser="";
	private int tcPassCount=0;
	private int tcFailCount=0;
	private int tcSkippedCount=0;
	private int tcTotalCount=0;
	public String getBrowser() {
		return browser;
	}
	public void setBrowser(String browser) {
		this.browser = browser;
	}
	public int getTcPassCount() {
		return tcPassCount;
	}
	public void setTcPassCount(int tcPassCount) {
		this.tcPassCount = tcPassCount;
	}
	public int getTcFailCount() {
		return tcFailCount;
	}
	public void setTcFailCount(int tcFailCount) {
		this.tcFailCount = tcFailCount;
	}
	public int getTcSkippedCount() {
		return tcSkippedCount;
	}
	public void setTcSkippedCount(int tcSkippedCount) {
		this.tcSkippedCount = tcSkippedCount;
	}
	public int getTcTotalCount() {
		return tcTotalCount;
	}
	public void setTcTotalCount(int tcTotalCount) {
		this.tcTotalCount = tcTotalCount;
	}
}