package report_utilities.test_result_model;

public class ModuleResult {

	private String module="";
	private int tcPassCount=0;
	private int tcFailCount=0;
	private int tcSkippedCount=0;
	private int tcTotalCount=0;
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public int getTcPassCount() {
		return tcPassCount;
	}
	public void setTcPassCount(int tcPassCount) {
		this.tcPassCount = tcPassCount;
	}
	public int getTcFailCount() {
		return tcFailCount;
	}
	public void setTcFailCount(int tcFailCount) {
		this.tcFailCount = tcFailCount;
	}
	public int getTcSkippedCount() {
		return tcSkippedCount;
	}
	public void setTcSkippedCount(int tcSkippedCount) {
		this.tcSkippedCount = tcSkippedCount;
	}
	public int getTcTotalCount() {
		return tcTotalCount;
	}
	public void setTcTotalCount(int tcTotalCount) {
		this.tcTotalCount = tcTotalCount;
	}
	
}