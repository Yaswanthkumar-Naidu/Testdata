package report_utilities.test_result_model;

import java.time.LocalDateTime;

public class TestCaseResult {

	private String testcaseName="";
	private String testcaseDescription="";
	private String testcaseCategory="";
	private String module="";
	private String browser="";
	private String testcaseStatus="";
	private LocalDateTime startTime=LocalDateTime.now();
	private LocalDateTime endTime=LocalDateTime.now();
	private String duration="";
	
	//**********Temp Chnages//
	private String caseNumber="";
	private String applicationNumber="";
	
	//****************//
	public String getModule() {
        return module;
    }
	
	public String getBrowser() {
        return browser;
    }
	
	public LocalDateTime getStartTime()
	{
		return startTime;
	}
	
	public LocalDateTime getEndTime()
	{
		return endTime;
	}

	public String getTestcaseName() {
		return testcaseName;
	}

	public void setTestcaseName(String testcaseName) {
		this.testcaseName = testcaseName;
	}

	public String getTestcaseDescription() {
		return testcaseDescription;
	}

	public void setTestcaseDescription(String testcaseDescription) {
		this.testcaseDescription = testcaseDescription;
	}

	public String getTestcaseCategory() {
		return testcaseCategory;
	}

	public void setTestcaseCategory(String testcaseCategory) {
		this.testcaseCategory = testcaseCategory;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getCaseNumber() {
		return caseNumber;
	}

	public void setCaseNumber(String caseNumber) {
		this.caseNumber = caseNumber;
	}

	public String getApplicationNumber() {
		return applicationNumber;
	}

	public void setApplicationNumber(String applicationNumber) {
		this.applicationNumber = applicationNumber;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public String getTestcaseStatus() {
		return testcaseStatus;
	}

	public void setTestcaseStatus(String testcaseStatus) {
		this.testcaseStatus = testcaseStatus;
	}

	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}
	
	public void setEndTime(LocalDateTime startTime) {
		this.endTime = startTime;
	}
}